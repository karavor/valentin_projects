#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <iomanip>
#include "my_structs.h"

using namespace std;

template<typename _DT_>
void write_vect_as_string (vector<_DT_>* vect,
                           ofstream* write,
                           char sep = '%'    )
{
    bool sep_flag = 0;

    if (sep != '%')
        sep_flag = 1;

    for (int i = 0; i < (*vect).size(); i++)
    {
        (*write) << (*vect)[i];

        if (sep_flag)
            (*write) << sep;
    }
}

void olig_from_nmbs_to_string_convert (string* str_olig,
                                       vector<unsigned short int>* nmbs_olig,
                                       vector<string>* pttrn_base)
{
    (*str_olig).clear();

    for (int i = 0; i < (*nmbs_olig).size(); i++)
    {
        (*str_olig) += (*pttrn_base)[ (*nmbs_olig)[i] ];
    }
}

float dG_reader (string* seq, bool dna_flag);

float max_pttrn_cmplx_dG_calc (int pttrn_length, bool dna_flag);

void result_data_writer (float crit_score,
                         int pttrn_length,
                         bool dna_flag,
                         vector<string>* pttrn_base,
                         vector< A_n_k_elmnt_with_nmb >* final_oligs_base)
{
    const char* AAGS_result_file = "../output/AAGS_result";
    string final_olig;

    ofstream write_good( AAGS_result_file );
    write_good << setprecision(3);

    ofstream write_bad( "../output/AAGS_bad_result" );
    write_bad << setprecision(3);

    ofstream* write;

    string double_final_olig;

    float dG,
          self_dG,
          max_pttrn_cmplx_dG = max_pttrn_cmplx_dG_calc (pttrn_length, dna_flag);

    for (int i = 0; i < (*final_oligs_base).size(); i++)
    {
        olig_from_nmbs_to_string_convert(&final_olig,
                                         &((*final_oligs_base)[i].elmnt),
                                         pttrn_base                      );

        dG = dG_reader (&final_olig, dna_flag);
        self_dG = dG_reader (&(double_final_olig = final_olig + "+" + final_olig), dna_flag);

        if (   dG   / max_pttrn_cmplx_dG > crit_score
            ||
            self_dG / max_pttrn_cmplx_dG > crit_score )
        {
            write = &write_bad;
        }
        else
            write = &write_good;

        write_vect_as_string<unsigned short int>( &((*final_oligs_base)[i].elmnt), write, ' ' );
        (*write) << endl;

        (*write) << final_olig << endl
                 << "dG =" << '\t' << dG << endl
                 << "self_dG =" << '\t' << self_dG << endl << endl;

        final_olig.clear();
        double_final_olig.clear();
    }
    write_bad.close();
    write_good.close();
}
