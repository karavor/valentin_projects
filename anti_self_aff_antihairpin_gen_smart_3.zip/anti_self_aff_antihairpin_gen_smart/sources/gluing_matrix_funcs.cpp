#include <string>
#include <vector>
#include <cmath>
#include <fstream>
#include <iostream>
#include <iomanip>
#include "my_structs.h"

using namespace std;

int  string_in_base_finder (string* pttrn,
                            vector<string>* pttrn_base)
{
    for (int i = 0; i < (int)(*pttrn_base).size(); i++)
    {
        if ( (*pttrn) == (*pttrn_base)[i] )
            return i;
    }
    //cout << endl << "There's no such pattern in base" << endl;
    return -1;
}

bool appeared_pttrns_of_gluing_nmbs (vector<string>* pttrn_base,
                                     two_pttrn_gluing*  gluing_matrix_element,
                                     int i,
                                     int j)
{
    string appeared_pttrn;
    string gluing = ( (*pttrn_base)[i] ) + ( (*pttrn_base)[j] );
    gluing.erase( gluing.begin() );
    gluing.erase( gluing.begin() + gluing.length() - 1 );

    int pttrn_length = (int)( (*pttrn_base)[0] ).length();
    int appeared_pttrn_nmb;

    for (int k = 0; k < pttrn_length - 1; k++)
    {
        for (int l = k; l < k + pttrn_length; l++)
        {
            appeared_pttrn.push_back( gluing[l] );
        }
        appeared_pttrn_nmb = string_in_base_finder (&appeared_pttrn, pttrn_base);

        ( (*gluing_matrix_element).appeared_pttrns_nmbs ).push_back( appeared_pttrn_nmb );
        appeared_pttrn.clear();
    }
    return 0;
}

float dG_reader (string* seq, bool dna_flag);

float max_pttrn_cmplx_dG_calc (int pttrn_length, bool dna_flag)
{
    string worst_pttrn_cmplx;

    for (int i = 0; i < pttrn_length; i++)
    {
        worst_pttrn_cmplx.push_back('C');
    }
    worst_pttrn_cmplx.push_back('+');

    for (int i = 0; i < pttrn_length; i++)
    {
        worst_pttrn_cmplx.push_back('G');
    }
    return dG_reader(&worst_pttrn_cmplx, dna_flag);
}

float double_pttrn_score_calc (string* pttrn_1,
                               string* pttrn_2,
                               bool dna_flag,
                               float max_pttrn_cmplx_dG)
{
    string pttrn_self_cmplx = (*pttrn_1) + "+" + (*pttrn_2);
cout << pttrn_self_cmplx << endl;
cout << dG_reader(&pttrn_self_cmplx, dna_flag) << endl;
    return abs( dG_reader(&pttrn_self_cmplx, dna_flag)/max_pttrn_cmplx_dG );
}

template<typename _DT_>
void write_vect_as_string (vector<_DT_>* vect,
                           ofstream* write,
                           char sep = '%'    )
{
    bool sep_flag = 0;

    if (sep != '%')
        sep_flag = 1;

    for (int i = 0; i < (*vect).size(); i++)
    {
        (*write) << (*vect)[i];

        if (sep_flag)
            (*write) << sep;
    }
}

void gluing_matrix_writer (vector<string>* pttrn_base,
                           vector< vector<two_pttrn_gluing> >* gluing_matrix)
{
    char sep = '\t';
    ofstream write ("../input/gluing_matrix");
    write << setprecision(3);

    for (int i = 0; i < (*pttrn_base).size(); i++)
        write << sep << i << sep << (*pttrn_base)[i];

    write << endl;

    for (int i = 0; i < (*pttrn_base).size(); i++) // string in gluing_matrix
    {
        write << (*pttrn_base)[i];

        for (int j = 0; j < (*pttrn_base).size(); j++) //column in gluing_matrix
        {
            write << sep << (*gluing_matrix)[i][j].cmplx_dG_score << sep;

            write_vect_as_string<int>(&( (*gluing_matrix)[i][j].appeared_pttrns_nmbs ),
                                      &write,
                                      '_'    );
        }
        write << sep << endl;
    }
    write.close();
}

float gluing_matrix_maker (vector<string>* pttrn_base,
                           vector< vector<two_pttrn_gluing> >* gluing_matrix,
                           bool dna_flag)
{
    two_pttrn_gluing gluing_matrix_element;
    vector<two_pttrn_gluing> gluing_matrix_string;

    float max_pttrn_cmplx_dG = max_pttrn_cmplx_dG_calc ((*pttrn_base)[0].length(), dna_flag);

    for (int i = 0; i < (*pttrn_base).size(); i++) // string in gluing_matrix
    {
        for (int j = 0; j < (*pttrn_base).size(); j++) //column in gluing_matrix
        {
            gluing_matrix_element.cmplx_dG_score
            =
            double_pttrn_score_calc ( &( (*pttrn_base)[i] ),
                                      &( (*pttrn_base)[j] ),
                                      dna_flag,
                                      max_pttrn_cmplx_dG);

            appeared_pttrns_of_gluing_nmbs (pttrn_base,
                                            &gluing_matrix_element,
                                            i,
                                            j);

            gluing_matrix_string.push_back(gluing_matrix_element);
            (gluing_matrix_element.appeared_pttrns_nmbs).clear();
        }
        (*gluing_matrix).push_back(gluing_matrix_string);
        gluing_matrix_string.clear();
    }
    gluing_matrix_writer(pttrn_base, gluing_matrix);

    return max_pttrn_cmplx_dG;
}

float decimal_numb_reader( string* s );

int int_numb_reader (string* s);

bool gluing_matrix_reader( vector< vector<two_pttrn_gluing> >* gluing_matrix,
                           int gluing_matrix_size )
{
    ifstream read("../input/gluing_matrix");
    string read_str;
    string current_data;
    vector<two_pttrn_gluing> current_gluing_matrix_string;
    two_pttrn_gluing current_matrix_elmnt;
    char big_sep   = '\t',
         small_sep = '_' ;
    int k;

    getline(read, read_str);

    for (int i = 0; i < gluing_matrix_size; i++)
    {
        getline(read, read_str);
        k = read_str.find(big_sep);

        for (int j = 0; j < gluing_matrix_size; j++)
        {
            for (k = k + 1; read_str[k] != big_sep; k++)
            {
                current_data.push_back(read_str[k]);
            }
            current_matrix_elmnt.cmplx_dG_score = decimal_numb_reader(&current_data);
            current_data.clear();

            for (k = k + 1; read_str[k] != big_sep; k++)
            {
                for (k; read_str[k] != small_sep; k++)
                {
                    current_data.push_back(read_str[k]);
                }
                current_matrix_elmnt.appeared_pttrns_nmbs.push_back( int_numb_reader(&current_data) );
                current_data.clear();
            }
            current_gluing_matrix_string.push_back(current_matrix_elmnt);
            current_matrix_elmnt.appeared_pttrns_nmbs.clear();
        }
        (*gluing_matrix).push_back(current_gluing_matrix_string);
        current_gluing_matrix_string.clear();
    }
    read.close();
    return 0;
}
