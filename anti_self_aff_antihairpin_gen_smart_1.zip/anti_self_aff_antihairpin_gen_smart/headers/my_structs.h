#ifndef MY_STRUCTS_H_INCLUDED
#define MY_STRUCTS_H_INCLUDED

using namespace std;

struct two_pttrn_gluing
{
    float cmplx_dG_score;
    vector<int> appeared_pttrns_nmbs; //in order from 5' to 3'
};

struct A_n_k_elmnt_with_nmb
{
    unsigned short int nmb;
    vector<unsigned short int> elmnt;
};

#endif // MY_STRUCTS_H_INCLUDED
