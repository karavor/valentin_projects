#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "main.h"
#include <iomanip>

using namespace std;
 // text file input should exist

float max_pttrn_cmplx_dG_calc (int pttrn_length, bool dna_flag)
{
    string worst_pttrn_cmplx;

    for (int i = 0; i < pttrn_length; i++)
    {
        worst_pttrn_cmplx.push_back('C');
    }
    worst_pttrn_cmplx.push_back('+');

    for (int i = 0; i < pttrn_length; i++)
    {
        worst_pttrn_cmplx.push_back('G');
    }
    return dG_reader(&worst_pttrn_cmplx, dna_flag);
}

template<class _T_>

void vect_vect_mem_free (vector< vector<_T_> >* vect_vect)
{
    for (int i = 0; i < (*vect_vect).size(); i++)
    {
        ((*vect_vect)[i]).clear();
    }
    (*vect_vect).clear();
}

template<typename _DT_>
void write_vect_as_string (vector<_DT_>* vect,
                           ofstream* write    )
{
    for (int i = 0; i < (*vect).size(); i++)
    {
        (*write) << (*vect)[i];
    }
}

void olig_from_nmbs_to_string_convert (string* str_olig,
                                       vector<unsigned short int>* nmbs_olig,
                                       vector<string>* pttrn_base)
{
    (*str_olig).clear();

    for (int i = 0; i < (*nmbs_olig).size(); i++)
    {
        (*str_olig) += (*pttrn_base)[ (*nmbs_olig)[i] ];
    }
}

void result_data_writer (bool dna_flag,
                         vector<string>* pttrn_base,
                         vector< A_n_k_elmnt_with_nmb >* final_oligs_base)
{
    const char* AAGS_result_file = "../output/AAGS_result";
    string final_olig;

    ofstream write;
    write.open( AAGS_result_file );
    write << setprecision(3);

    for (int i = 0; i < (*final_oligs_base).size(); i++)
    {
        write_vect_as_string<unsigned short int>( &((*final_oligs_base)[i].elmnt), &write );
        write << endl;
        olig_from_nmbs_to_string_convert(&final_olig,
                                         &((*final_oligs_base)[i].elmnt),
                                         pttrn_base                      );
        write << final_olig << endl
              << "dG =" << '\t'
              << dG_reader (&final_olig, dna_flag) << endl
              << "self_dG =" << '\t'
              << dG_reader (&(final_olig = final_olig + "+" + final_olig), dna_flag) << endl << endl;
    }

    write.close();
}

int main()
{
    bool  gluing_matrix_count_flag,
          dna_flag;
    int   pttrn_length,
          pttrn_nmb_in_olig;
    float crit_score;

    input_data_reader (&gluing_matrix_count_flag,
                       &dna_flag,
                       &pttrn_length,
                       &pttrn_nmb_in_olig,
                       &crit_score,
                       ' ');

    float max_pttrn_cmplx_dG = max_pttrn_cmplx_dG_calc (pttrn_length, dna_flag);

    vector<string> pttrn_base;
    pttrn_base_generator (&pttrn_base,
                          pttrn_length,
                          dna_flag);

cout << "pttrn_base_generator well done" << endl;

    vector< vector<two_pttrn_gluing> > gluing_matrix; //like column of the strings

    if (gluing_matrix_count_flag)
    {
        gluing_matrix_maker (&pttrn_base,
                             &gluing_matrix,
                             dna_flag,
                             max_pttrn_cmplx_dG);

        cout << "gluing_matrix well done" << endl;
    }
    else gluing_matrix_reader(&gluing_matrix);


    vector< A_n_k_elmnt_with_nmb > final_oligs_base;

    modified_A_n_k_maker ( pttrn_base.size(),
                           pttrn_nmb_in_olig,
                           &final_oligs_base,
                           crit_score,
                           &gluing_matrix );

cout << "modified_A_n_k_maker well done" << endl;

    result_data_writer (dna_flag,
                        &pttrn_base,
                        &final_oligs_base);

cout << "result_data_writer well done" << endl;

    return 0;
}
