#include <string>
#include <vector>
#include <cmath>

using namespace std;

int left_decade_pop (int* left_decade_nmb,
                     int* right_decade_nmb,
                     int  max_nmb)
{
    if ( (*right_decade_nmb) > max_nmb )
    {
        (*right_decade_nmb) = 0;
        (*left_decade_nmb)++;
        return 0;
    }
    return 1;
}

char ncltd_generator (int ncltd_nmb, bool dna_flag) //ncltd_nmb can be 0, 1, 2 or 3
{
    char ncltds [4] = {'A', 'U', 'G', 'C'};

    if (dna_flag)
        ncltds[1] = 'T';

    return ncltds[ncltd_nmb];
}

void pttrn_base_generator (vector<string>* pttrn_base,
                           int pttrn_length,
                           bool dna_flag)
{
    string current_pttrn;
    int n = 4,
        k = pttrn_length;

    int comb_nmb = (int)pow(n, k);
    int n_pow_k_arr [k];

    for (int i = 0; i < k; i++)
        n_pow_k_arr[i] = 0;

    for (int i = 0; i < comb_nmb; i++)
    {
        for (int j = 0; j < k; j++)
        {
            current_pttrn.push_back( ncltd_generator (n_pow_k_arr[j], dna_flag) );
        }

        (*pttrn_base).push_back(current_pttrn);

        current_pttrn.clear();

        n_pow_k_arr[0]++;

        for (int l = 0; l < (k - 1); l++)
        {
            if ( left_decade_pop( &(n_pow_k_arr[l + 1]),
                                  &(n_pow_k_arr[l]),
                                  (n - 1)               ) )
                break;
        }
    }
}
