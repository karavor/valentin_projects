#include <string>
#include <vector>
#include <cmath>
#include <fstream>
#include <iomanip>
#include "my_structs.h"

using namespace std;

int  string_in_base_finder (string* pttrn,
                            vector<string>* pttrn_base)
{
    for (int i = 0; i < (int)(*pttrn_base).size(); i++)
    {
        if ( (*pttrn) == (*pttrn_base)[i] )
            return i;
    }
    //cout << endl << "There's no such pattern in base" << endl;
    return -1;
}

bool appeared_pttrns_of_gluing_nmbs (vector<string>* pttrn_base,
                                     two_pttrn_gluing*  gluing_matrix_element,
                                     int i,
                                     int j)
{
    string appeared_pttrn;
    string gluing = ( (*pttrn_base)[i] ) + ( (*pttrn_base)[j] );
    gluing.erase( gluing.begin() );
    gluing.erase( gluing.begin() + gluing.length() - 1 );

    int pttrn_length = (int)( (*pttrn_base)[0] ).length();
    int appeared_pttrn_nmb;

    for (int k = 0; k < pttrn_length - 1; k++)
    {
        for (int l = k; l < k + pttrn_length; l++)
        {
            appeared_pttrn.push_back( gluing[l] );
        }
        appeared_pttrn_nmb = string_in_base_finder (&appeared_pttrn, pttrn_base);

        ( (*gluing_matrix_element).appeared_pttrns_nmbs ).push_back( appeared_pttrn_nmb );
        appeared_pttrn.clear();
    }
    return 0;
}

float dG_reader (string* seq, bool dna_flag);

float double_pttrn_score_calc (string* pttrn_1,
                               string* pttrn_2,
                               bool dna_flag,
                               float max_pttrn_cmplx_dG)
{
    string pttrn_self_cmplx = (*pttrn_1) + "+" + (*pttrn_2);
    return abs( dG_reader(&pttrn_self_cmplx, dna_flag)/max_pttrn_cmplx_dG );
}

template<typename _DT_>
void write_vect_as_string (vector<_DT_>* vect,
                           ofstream* write    );

void gluing_matrix_writer (vector<string>* pttrn_base,
                           vector< vector<two_pttrn_gluing> >* gluing_matrix)
{
    char sep = '\t';
    ofstream write ("../input/gluing_matrix");
    write << setprecision(3);

    for (int i = 0; i < (*pttrn_base).size(); i++)
        write << sep << i << sep << (*pttrn_base)[i];

    for (int i = 0; i < (*pttrn_base).size(); i++) // string in gluing_matrix
    {
        write << (*pttrn_base)[i];

        for (int j = 0; j < (*pttrn_base).size(); j++) //column in gluing_matrix
        {
            write << sep << (*gluing_matrix)[i][j].cmplx_dG_score << sep;

            write_vect_as_string<int>(&( (*gluing_matrix)[i][j].appeared_pttrns_nmbs ),
                                      &write);
        }
        write << endl;
    }
    write.close();
}

bool gluing_matrix_maker (vector<string>* pttrn_base,
                          vector< vector<two_pttrn_gluing> >* gluing_matrix,
                          bool dna_flag,
                          float max_pttrn_cmplx_dG)
{
    two_pttrn_gluing gluing_matrix_element;
    vector<two_pttrn_gluing> gluing_matrix_string;

    for (int i = 0; i < (*pttrn_base).size(); i++) // string in gluing_matrix
    {
        for (int j = 0; j < (*pttrn_base).size(); j++) //column in gluing_matrix
        {
            gluing_matrix_element.cmplx_dG_score
            =
            double_pttrn_score_calc ( &( (*pttrn_base)[i] ),
                                      &( (*pttrn_base)[j] ),
                                      dna_flag,
                                      max_pttrn_cmplx_dG);

            appeared_pttrns_of_gluing_nmbs (pttrn_base,
                                            &gluing_matrix_element,
                                            i,
                                            j);

            gluing_matrix_string.push_back(gluing_matrix_element);
            (gluing_matrix_element.appeared_pttrns_nmbs).clear();
        }
        (*gluing_matrix).push_back(gluing_matrix_string);
        gluing_matrix_string.clear();
    }
    gluing_matrix_writer(pttrn_base, gluing_matrix);

    return 0;
}

float decimal_numb_reader( string* s );

void gluing_matrix_reader( vector< vector<two_pttrn_gluing> >* gluing_matrix )
{
    ifstream read("../input/gluing_matrix");
    string read_str;
    string current_data;
    vector<two_pttrn_gluing> current_gluing_matrix_string;
    two_pttrn_gluing current_matrix_elmnt;
    char sep = '\t';
    int i = 0, j = 0, k;

    getline(read, read_str);

    while (!read.eof())
    {
        getline(read, read_str);
        k = read.find(sep) + 1;

        for (k; read[k] != sep; k++)
        {
            current_data.push_back(read[k]);
        }
        (*gluing_matrix)[i][j].cmplx_dG_score = decimal_numb_reader(&current_data);

        current_data.clear();

        for (k = k + 1; read[k] != sep; k++)
        {
            current_data.push_back(read[k]);
        }

        for (int l = 0; l < current_data.size(); l++)
        {
            (*gluing_matrix)[i][j].appeared_pttrns_nmbs.push_back( (int)current_data[l] );
        }
        current_data.clear();

        i++;
        j = 0;
    }

    read.close();
}
