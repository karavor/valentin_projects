#include <iostream>
#include <string>
#include <vector>
#include "main.h"

using namespace std;

template<class _T_>

void vect_vect_mem_free (vector< vector<_T_> >* vect_vect)
{
    for (int i = 0; i < (*vect_vect).size(); i++)
    {
        ((*vect_vect)[i]).clear();
    }
    (*vect_vect).clear();
}

int main()
{
    bool  gluing_matrix_culc_flag,
          dna_flag;
    int   pttrn_length,
          pttrn_nmb_in_olig;
    float crit_score;

    input_data_reader (&gluing_matrix_culc_flag,
                       &dna_flag,
                       &pttrn_length,
                       &pttrn_nmb_in_olig,
                       &crit_score,
                       ' ');

    vector<string> pttrn_base;
    pttrn_base_generator (&pttrn_base,
                          pttrn_length,
                          dna_flag);

cout << "pttrn_base_generator well done" << endl;

    vector< vector<two_pttrn_gluing> > gluing_matrix; //like column of the strings

    if (gluing_matrix_culc_flag)
    {
        gluing_matrix_maker (&pttrn_base,
                             &gluing_matrix,
                             dna_flag);

        cout << "gluing_matrix_maker well done" << endl;
    }
    else gluing_matrix_reader( &gluing_matrix,
                               pttrn_base.size() );

    vector< A_n_k_elmnt_with_nmb > final_oligs_base;

    modified_A_n_k_maker ( pttrn_base.size(),
                           pttrn_nmb_in_olig,
                           &final_oligs_base,
                           crit_score,
                           &gluing_matrix );

cout << "modified_A_n_k_maker well done" << endl;

    result_data_writer (dna_flag,
                        &pttrn_base,
                        &final_oligs_base);

cout << "result_data_writer well done" << endl;

    return 0;
}
