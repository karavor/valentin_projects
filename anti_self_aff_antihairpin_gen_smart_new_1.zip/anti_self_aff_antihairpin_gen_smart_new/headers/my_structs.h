#ifndef MY_STRUCTS_H_INCLUDED
#define MY_STRUCTS_H_INCLUDED

using namespace std;

struct two_pttrn_gluing
{
    float cmplx_dG_score;
    vector<int> appeared_pttrns_nmbs; //in order from 5' to 3'
};

struct A_n_k_elmnt_struct
{
    vector<unsigned short int> elmnt;
    float max_pttrn_cmplx_dG_score;
    vector<unsigned short int> max_pttrn_cmplx_nmbs;
};

#endif // MY_STRUCTS_H_INCLUDED
