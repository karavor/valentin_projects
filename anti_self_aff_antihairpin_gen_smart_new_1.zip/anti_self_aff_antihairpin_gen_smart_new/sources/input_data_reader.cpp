#include <fstream>
#include <string>

using namespace std;

float decimal_numb_reader( string* s );

float string_with_prmtr_reader(ifstream* read,
                               char      sep)
{
    string read_str;
    getline( (*read), read_str);
    read_str.erase( read_str.begin(), read_str.begin() + read_str.find( sep ) + 1 );
    return decimal_numb_reader(&read_str);
}

void input_data_reader (bool*    gluing_matrix_culc_flag,
                        bool*    dna_flag,
                        int*     pttrn_length,
                        int*     pttrn_nmb_in_olig,
                        float*   crit_score,
                        char     sep = ' ')
{
    const char* input_file_path = "../input/AAGS_input";

    ifstream read;
    read.open(input_file_path);

    (*gluing_matrix_culc_flag) = string_with_prmtr_reader(&read, sep);
    (*dna_flag)          = string_with_prmtr_reader(&read, sep);
    (*pttrn_length)      = string_with_prmtr_reader(&read, sep),
    (*pttrn_nmb_in_olig) = string_with_prmtr_reader(&read, sep);
    (*crit_score)        = string_with_prmtr_reader(&read, sep);

    read.close();
}
