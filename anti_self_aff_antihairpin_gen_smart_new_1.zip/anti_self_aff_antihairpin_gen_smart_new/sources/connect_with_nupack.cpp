#include <string>
#include <fstream>
#include <cstdlib>

using namespace std;

#define MFE_FUNC_DNA "\
    #/bin/bash \n\
    export NUPACKHOME=/home/valentin/work_backup/nupack \n\
    $NUPACKHOME/bin/mfe -material dna $PWD/../input/input_seq \n\
"

#define MFE_FUNC_RNA "\
    #/bin/bash \n\
    export NUPACKHOME=/home/valentin/work_backup/nupack \n\
    $NUPACKHOME/bin/mfe -material rna $PWD/../input/input_seq \n\
"

#define CONCENTRATIONS_FUNC "\
    #/bin/bash \n\
    export NUPACKHOME=/home/valentin/work_backup/nupack \n\
    $NUPACKHOME/bin/complexes -T 23 -material rna -quiet $PWD/../input/complex \n\
    $NUPACKHOME/bin/concentrations -quiet $PWD/../input/complex \n\
"

#define CONCENTRATIONS_FUNC_DNA "\
    #/bin/bash \n\
    export NUPACKHOME=/home/valentin/work_backup/nupack \n\
    $NUPACKHOME/bin/complexes -T 23 -material dna $PWD/../input/complex \n\
    $NUPACKHOME/bin/concentrations $PWD/../input/complex \n\
"

#define CLEAN_FUNC "\
    #/bin/bash \n\
    rm $PWD/../input/input_seq.in \n\
    rm $PWD/../input/input_seq.mfe \n\
"

float decimal_numb_reader( string* s );

float dG_reader (string* seq, bool dna_flag)
{
    const char* input_mfe     = "../input/input_seq.in";
    const char* output_mfe    = "../input/input_seq.mfe";

    ofstream w;
    w.open(input_mfe);
    w << *seq;
    w.close();

    if (dna_flag)
         system(MFE_FUNC_DNA);
    else system(MFE_FUNC_RNA);

    string temporal_str;

    ifstream r;
    r.open(output_mfe);

    for (int i = 0; i < 15; i++)
    {
        getline(r, temporal_str);
    }

    if (temporal_str.length() == 0)
        return 0;

    return decimal_numb_reader( &temporal_str);
}

float exp_numb_reader(string* s);

float aff_reader (string* seq_1, string* seq_2, int dna_flag = 0)
{
    const char* conc_input    = "../input/complex.in"; // file complex.con should exist
    const char* conc_output   = "../input/complex.eq";

    ofstream w;
    w.open(conc_input);
    w << 2        << endl
      << (*seq_1) << endl
      << (*seq_2) << endl
      << 2;
    w.close();
    if (dna_flag)
        system(CONCENTRATIONS_FUNC_DNA);
    else system(CONCENTRATIONS_FUNC);

    string temp_str;
    ifstream r;
    r.open(conc_output);

    do getline(r, temp_str);
    while (temp_str[0] == '%');

    while (temp_str[2] != temp_str[4])
    {
        getline(r, temp_str);

        if ( r.eof() )
            return 0;
    }

    r.close();
    string aff_str;

    for(int i = 20; temp_str[i] != '\t'; i++)
        aff_str.push_back(temp_str[i]);

    float aff = exp_numb_reader(&aff_str);
    return (aff/1e-06)*100;
}
