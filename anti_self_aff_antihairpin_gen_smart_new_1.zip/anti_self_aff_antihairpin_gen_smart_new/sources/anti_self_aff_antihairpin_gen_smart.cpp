#include <iostream>
#include <string>
#include <vector>
#include "main.h"

using namespace std;

template<class _T_>

void vect_vect_mem_free (vector< vector<_T_> >* vect_vect)
{
    for (int i = 0; i < (*vect_vect).size(); i++)
    {
        ((*vect_vect)[i]).clear();
    }
    (*vect_vect).clear();
}

bool modified_A_n_k_maker ( vector<string>* pttrn_base,
                            unsigned short int n,
                            unsigned short int k,
                            float crit_score,
                            vector< vector<two_pttrn_gluing> >* gluing_matrix );

bool gluing_matrix_analyse(vector< vector<two_pttrn_gluing> >* gluing_matrix);

int main()
{
    //result_data_worker(1);
    //return 0;

    bool  gluing_matrix_culc_flag,
          dna_flag;
    int   pttrn_length,
          pttrn_nmb_in_olig;
    float crit_score;

    input_data_reader (&gluing_matrix_culc_flag,
                       &dna_flag,
                       &pttrn_length,
                       &pttrn_nmb_in_olig,
                       &crit_score,
                       ' ');

    vector<string> pttrn_base;
    pttrn_base_generator (&pttrn_base,
                          pttrn_length,
                          dna_flag);

cout << "pttrn_base_generator well done" << endl;

    vector< vector<two_pttrn_gluing> > gluing_matrix; //like column of the strings

    if (gluing_matrix_culc_flag)
    {
        gluing_matrix_maker (&pttrn_base,
                             &gluing_matrix,
                             dna_flag);

        cout << "gluing_matrix_maker well done" << endl;
    }
    else gluing_matrix_reader( &gluing_matrix,
                               pttrn_base.size() );

//gluing_matrix_analyse(&gluing_matrix);
//return 0;

    modified_A_n_k_maker ( &pttrn_base,
                           pttrn_base.size(),
                           pttrn_nmb_in_olig,
                           crit_score,
                           &gluing_matrix );

cout << "modified_A_n_k_maker well done" << endl;

    return 0;
}
