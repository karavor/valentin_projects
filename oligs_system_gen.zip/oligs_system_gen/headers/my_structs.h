#ifndef MY_STRUCTS_H_INCLUDED
#define MY_STRUCTS_H_INCLUDED

#include <string>
#include <vector>
#include <iostream>

using namespace std;

void c_seq_maker (string* seq, string* c_seq, bool dna_flag);

struct olig_domain
{
    char name = '$';
    int length = 0;
    string nucl_seq; //in order from 5' to 3'

    void clear_func()
    {
        name = '$';
        length = 0;
        nucl_seq.clear();
    }
};

float dG_reader (string* seq, bool dna_flag);

struct domain_pair
{
    olig_domain first;
    olig_domain second;
    float complex_dG = 1;

    void pair_clear()
    {
        first.clear_func();
        second.clear_func();
    }

    void second_domain_maker(bool dna_flag)
    {
        second.clear_func();

        if ( first.nucl_seq.length() != 0 ||
             first.length != 0            )
        {
            if (second.name == '$')
            {
                 if (first.name <= 'Z')
                    second.name = first.name + ('a' - 'A');
                else
                    second.name = first.name - ('a' - 'A');
            }

            second.length = first.length;

            if ( first.nucl_seq.length() != 0 )
            {
                c_seq_maker( &(first.nucl_seq),
                             &(second.nucl_seq),
                             dna_flag           );
            }
        }
    }

    void complex_dG_calc ( bool dna_flag )
    {
        if ( first.nucl_seq.length() != 0 )

        {
            string seq = first.nucl_seq + "+" + second.nucl_seq;

            complex_dG = dG_reader(&seq, dna_flag);
        }
    }
};

struct domain_ref
{
    char dom_name = '$';
    bool iverse_flag = 0;
    domain_pair* dom_pair;
    olig_domain* olig_dom;
};

struct olig
{
    vector <domain_ref> dom_seq;

    float strongest_dG = 0;

    void strongest_dG_calc ()
    {
        strongest_dG = 0;

        float current_dG;

        for (int i = 0; i < dom_seq.size(); i++ )
        {
            if ( ( *(dom_seq[i].olig_dom) ).nucl_seq.length() == 0 )
                break;

            current_dG = ( *(dom_seq[i].dom_pair) ).complex_dG;

            if ( current_dG < strongest_dG )
            {
                strongest_dG = current_dG;
            }
        }
    }
};

struct input_prmtrs
{
    bool    dna_flag;
    int     max_iter_nmb_for_dmn_bld;
    float   crit_param_over_mult;
    float   hairpin_crit_dG;
    int     hairpin_length;
    float   cmplx_crit_dG;
    int     GC_percentage;
};

#endif // MY_STRUCTS_H_INCLUDED
