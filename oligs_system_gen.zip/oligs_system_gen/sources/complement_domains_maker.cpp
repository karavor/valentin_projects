#include <string>

using namespace std;

void string_inverser (string* s)
{
    string s_copy = (*s);

    int l = (*s).length();

    for (int i = 0; i < l; i++ )
    {
        (*s)[i] = s_copy[l-1-i];
    }
}

void c_seq_maker (string* seq, string* c_seq, bool dna_flag)
{
    (*c_seq).clear();

    for (int i = 0; i < (*seq).length(); i++ )
    {
        switch((*seq)[i])
        {
            case 'C':
                (*c_seq).push_back('G');
                break;
            case 'G':
                (*c_seq).push_back('C');
                break;
            case 'A':
                if (dna_flag)
                     (*c_seq).push_back('T');
                else (*c_seq).push_back('U');
                break;
            case 'U':
                (*c_seq).push_back('A');
                break;
            case 'T':
                (*c_seq).push_back('A');
                break;
        }
    }
    string_inverser(c_seq);
}
