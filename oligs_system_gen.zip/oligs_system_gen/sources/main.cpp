#include <vector>
#include "my_structs.h"
#include "main.h"

using namespace std;

int main()
{
    input_prmtrs inp_prmtrs;

    olig_domain neutral_domain;

    vector<domain_pair> domain_base;

    vector< vector< olig >* > oligs_pntrs;

    vector< olig > defined_oligs;
    oligs_pntrs.push_back(&defined_oligs);

    vector< olig > undefined_oligs;
    oligs_pntrs.push_back(&undefined_oligs);

    vector< olig > brackets;
    oligs_pntrs.push_back(&brackets);

    vector< olig > input_oligs;
    oligs_pntrs.push_back(&input_oligs);

    input_data_reader ( &neutral_domain,
                        &domain_base,
                        &inp_prmtrs,
                        '\t',
                        &oligs_pntrs );

    def_oligs_maker( &neutral_domain,
                     &domain_base,
                     &inp_prmtrs,
                     &oligs_pntrs  );

/*
    result_data_writer ( &neutral_domain,
                        &domain_base,
                        &inp_prmtrs,
                        '\t',
                        &oligs_pntrs );*/
    return 0;
}
