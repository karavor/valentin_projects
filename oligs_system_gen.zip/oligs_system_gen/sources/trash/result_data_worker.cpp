#include <fstream>
#include <string>
#include <iomanip>

using namespace std;

float dG_reader (string* seq, bool dna_flag);

float aff_reader (string* seq_1, string* seq_2, int dna_flag = 0);

void result_data_worker(bool dna_flag)
{
    string str,
           olig_seq;

    ofstream write( "../output/A_n_k_maker_stat_5_5_035" );
    write << setprecision(3);

    ifstream read( "../output/A_n_k_maker_stat" );

    char sep = '\t';
    int i;

    while( !read.eof() )
    {
        getline(read, str);

        //i = str.find(sep) + 1;

        for (i = 0; str[i] != sep; i++)
        {
            olig_seq.push_back(str[i]);
        }
        write << aff_reader(&olig_seq, &olig_seq, dna_flag) << sep;

        write << dG_reader(&olig_seq, dna_flag) << sep;

        olig_seq = olig_seq + "+" + olig_seq;

        write << dG_reader(&olig_seq, dna_flag) << endl;

        olig_seq.clear();
    }
    read.close();
    write.close();
}
