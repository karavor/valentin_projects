#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#include "my_structs.h"
#include <vector>

using namespace std;

bool input_data_reader ( olig_domain* neutral_domain,
                         vector<domain_pair>* domain_base,
                         input_prmtrs* inp_prmtrs,
                         char     sep,
                         vector< vector< olig >* >* oligs_pntrs);

bool def_oligs_maker( olig_domain* neutral_domain,
                      vector<domain_pair>* domain_base,
                      input_prmtrs* inp_prmtrs,
                      vector< vector< olig >* >* oligs_pntrs);

void result_data_writer ( olig_domain* neutral_domain,
                          vector<domain_pair>* domain_base,
                          input_prmtrs* inp_prmtrs,
                          char     sep,
                          vector< vector< olig >* >* oligs_pntrs);

#endif // MAIN_H_INCLUDED
