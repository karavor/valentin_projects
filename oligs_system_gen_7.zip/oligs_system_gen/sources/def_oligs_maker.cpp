#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "my_structs.h"

using namespace std;

float dG_reader (string* seq, bool dna_flag);

float dG_cmplx_reader ( string* seq_1,
                        string* seq_2,
                        bool dna_flag )
{
    string cmplx_seq = (*seq_1) + "+" + (*seq_2);

    return dG_reader( &cmplx_seq, dna_flag );
}

template<typename numb_dt>

numb_dt min_numb (numb_dt numb_1,
                  numb_dt numb_2)
{
    if (numb_1 > numb_2)
        return numb_2;

    return numb_1;
}

float dG_cmplx_test ( float cmplx_crit_dG,
                      //float cmplx_spec_dG,
                      string* seq_1,
                      string* seq_2,
                      bool dna_flag,
                      int cmplx_length,
                      ofstream* write_stat,
                           char sep       )
{
    float cmplx_dG = dG_cmplx_reader ( seq_1,
                                       seq_2,
                                       dna_flag )
                    -                             // this can be not correct
                    dG_reader (seq_1, dna_flag)
                    -
                    dG_reader (seq_2, dna_flag);

    //float max_crit_dG = max_numb<float>( cmplx_crit_dG, 0.3 * cmplx_spec_dG );

    (*write_stat) << sep << "dG_cmplx_test: " << ( (*seq_1) + "+" + (*seq_2) )
                  << sep << cmplx_dG << endl;

    float score_add = 0;
    float new_cmplx_crit_dG = cmplx_crit_dG;
    int min_length = min_numb<int>( (*seq_1).length(), (*seq_2).length() );

    if (  min_length < cmplx_length )
    {
        new_cmplx_crit_dG = cmplx_crit_dG * min_length / cmplx_length;
    }

    if ( cmplx_dG < new_cmplx_crit_dG )
    {
        score_add = ( cmplx_dG - cmplx_crit_dG) / cmplx_crit_dG;
        (*write_stat) << sep << score_add << endl;
        return score_add;
    }
    (*write_stat) << sep << score_add << endl;
    return 0;
}

void rndm_olig_gen (bool dna_flag,
                    int olig_length,
                    int GC_percentage,
                    string* olig_str,
                    unsigned long int* rndm_modifier);

void string_inverser (string* s);

bool def_olig_seq_cmplr (vector <domain_ref>* seq_doms,
                         string* def_olig_nucl_seq,
                         bool continue_flag = 0)
{
    (*def_olig_nucl_seq).clear();

    olig_domain* current_domain;
    string current_dom_nucl_seq;

    for (int i = 0; i < ( *seq_doms ).size(); i++)
    {
        current_domain = (*seq_doms)[i].olig_dom;

        if ( (*current_domain).nucl_seq.length() == 0)
        {
            if (continue_flag)
                continue;

            if (i == 0)
                return 1;

            current_domain = (*seq_doms)[i - 1].olig_dom;

            if ( (*current_domain).nucl_seq.length() < 6 )
                return 1;

            return 0;
        }
        current_dom_nucl_seq = (*current_domain).nucl_seq;

        if ( (*seq_doms)[i].neutral_dom_length != 0 )
        {
            for (int j = 0; j <= ( current_dom_nucl_seq.length() -
                                  (*seq_doms)[i].neutral_dom_length ); j++)
            {
                current_dom_nucl_seq.erase( current_dom_nucl_seq.begin(),
                                            current_dom_nucl_seq.begin() + 1);
            }
        }

        if ( (*seq_doms)[i].iverse_flag )
        {
            string_inverser( &current_dom_nucl_seq );
        }

        (*def_olig_nucl_seq) += current_dom_nucl_seq;
    }

    if ( (*current_domain).nucl_seq.length() < 6 )
        return 1;

    return 0;
}

bool score_test(float score,
                float best_score) //lower is better
{
    if (score >= best_score)
        return 1;

    return 0;
}

bool def_oligs_cmptblt (string* current_compl_dom,
                        olig_domain* neutral_domain,
                        input_prmtrs* inp_prmtrs,
                        vector< olig >* defined_oligs,
                        float* score,
                        float best_score,
                        string* current_olig_seq,
                        ofstream* write_stat,
                        char sep,
                        bool neutral_olig_test_flag = 0)
{
    (*write_stat) << "def_oligs_cmptblt" << endl;

    (*score)
    +=
    dG_cmplx_test ( (*inp_prmtrs).cmplx_crit_dG,
                        //4*(*inp_prmtrs).cmplx_crit_dG,
                        current_olig_seq,
                        &( (*neutral_domain).nucl_seq ),
                        (*inp_prmtrs).dna_flag,
                       (*inp_prmtrs).cmplx_length,
                       write_stat,
                       sep       );

    if ( score_test( (*score), best_score ) )
        return 1;

    if ( !neutral_olig_test_flag )
    {
        (*score)
        +=
        dG_cmplx_test ( (*inp_prmtrs).cmplx_crit_dG,
                        //4*(*inp_prmtrs).cmplx_crit_dG,
                        current_compl_dom,
                        &( (*neutral_domain).nucl_seq ),
                        (*inp_prmtrs).dna_flag,
                        (*inp_prmtrs).cmplx_length,
                        write_stat,
                        sep       );

        if ( score_test( (*score), best_score ) )
            return 1;
    }

    string def_olig_nucl_seq;

    domain_ref current_dom_ref;

    for (int i = 0; i < (*defined_oligs).size(); i++)
    {
        def_olig_seq_cmplr (&( (*defined_oligs)[i].dom_seq ),
                            &def_olig_nucl_seq);

        (*score)
        +=
        dG_cmplx_test ( (*inp_prmtrs).cmplx_crit_dG,
                        //(*defined_oligs)[i].strongest_dG,
                        current_olig_seq,
                        &def_olig_nucl_seq,
                        (*inp_prmtrs).dna_flag,
                        (*inp_prmtrs).cmplx_length,
                       write_stat,
                       sep       );

        if ( score_test( (*score), best_score ) ) //skip current variant
            return 1;

        for (int j = 0; j < (*defined_oligs)[i].dom_seq.size(); j++)
        {
            current_dom_ref = (*defined_oligs)[i].dom_seq[j];

            if ( current_dom_ref.dom_name == (*neutral_domain).name
                 ||
                 ( *(current_dom_ref.dom_pair) ).neutral_dom_flag == 1 )
                continue;

            if ( ( *(current_dom_ref.dom_pair) ).second.nucl_seq.length() < 6 )
                continue;

            (*score)
            +=
            dG_cmplx_test ( (*inp_prmtrs).cmplx_crit_dG,
                            //( *(current_dom_ref.dom_pair) ).complex_dG,
                            current_olig_seq,
                            &( ( *(current_dom_ref.dom_pair) ).second.nucl_seq ),
                            (*inp_prmtrs).dna_flag,
                            (*inp_prmtrs).cmplx_length,
                           write_stat,
                           sep       );

            if ( score_test( (*score), best_score ) )
                return 1;
        }
    }
    return 0;
}

float dG_hairpin_test (float   hairpin_crit_dG,
                       int     hairpin_length,
                       string* seq,
                       bool    dna_flag,
                       ofstream* write_stat,
                       char sep)
{
    float hairpin_dG = dG_reader( seq, dna_flag );

    float modif_crit_dG = hairpin_crit_dG * (*seq).length() / hairpin_length;

    (*write_stat) << sep << "hairp_test: " << (*seq)
                  << sep << hairpin_dG
                  << sep << modif_crit_dG
                  << sep << endl;

    if ( hairpin_dG < modif_crit_dG )
    {
        return (hairpin_dG - modif_crit_dG) / modif_crit_dG;
    }
    return 0;
}

bool self_olig_cmptblt (char neutral_dom_name,
                        input_prmtrs* inp_prmtrs,
                        olig* current_olig,
                        float* score,
                        float best_score,
                        string* current_olig_seq,
                        ofstream* write_stat,
                        char sep)
{
    (*write_stat) << "self_olig_cmptblt" << sep << (*current_olig_seq) << endl;

    (*score)
    +=
    dG_hairpin_test ( (*inp_prmtrs).hairpin_crit_dG,
                      (*inp_prmtrs).hairpin_length,
                      current_olig_seq,
                      (*inp_prmtrs).dna_flag,
                      write_stat, sep   );

    if ( score_test( (*score), best_score ) )
            return 1;

    (*score)
    +=
    dG_cmplx_test ( (*inp_prmtrs).cmplx_crit_dG,
                    //( *current_olig ).strongest_dG,
                    current_olig_seq,
                    current_olig_seq,
                    (*inp_prmtrs).dna_flag,
                   (*inp_prmtrs).cmplx_length,
                   write_stat,
                   sep       );

    if ( score_test( (*score), best_score ) )
            return 1;

    domain_ref current_domain_ref;
    vector <domain_ref> dom_seq_copy = (*current_olig).dom_seq;
    string olig_seq;

    for (int i = 0; i < (*current_olig).dom_seq.size() - 1; i++)
    {
        dom_seq_copy.erase( dom_seq_copy.begin(),
                            dom_seq_copy.begin() + 1  );

        current_domain_ref = (*current_olig).dom_seq[i];

        if ( current_domain_ref.dom_name == neutral_dom_name )

            continue;

        if ( def_olig_seq_cmplr (&dom_seq_copy,
                                 &olig_seq     ) )
            break;

        if ( olig_seq.length() == 0 )
            break;

        if ( ( *(current_domain_ref.dom_pair) ).second.nucl_seq.length() < 6)
            continue;

        (*score)
        +=
        dG_cmplx_test ( (*inp_prmtrs).cmplx_crit_dG,
                        //( *(current_domain_ref.dom_pair) ).complex_dG,
                        &olig_seq,
                        & ( ( *(current_domain_ref.dom_pair) ).second.nucl_seq ),
                        (*inp_prmtrs).dna_flag,
                       (*inp_prmtrs).cmplx_length,
                       write_stat,
                       sep       );

        if ( score_test( (*score), best_score ) )
            return 1;
    }
    return 0;
}

bool olig_to_olig_link_detector (olig* olig_1, //def or undef olig
                                 olig* olig_2, // bracket or input olig
                                 char neutral_dom_name)
{
    for (int i = 0; i < (*olig_1).dom_seq.size(); i++)
    {
        if ( (*olig_1).dom_seq[i].dom_name == neutral_dom_name )
            continue;

        if ( ( *( (*olig_1).dom_seq[i].olig_dom ) ).nucl_seq.length() == 0 )
            return 0;

        for (int j = 0; j < (*olig_2).dom_seq.size(); j++)
        {
            if ( ( *( (*olig_1).dom_seq[i].dom_pair ) ).second.name
                 ==
                 (*olig_2).dom_seq[j].dom_name  )

                return 1;
        }
    }
    return 0;
}

bool bracket_cmptblt( olig*           cur_olig,
                      char            compl_name_to_cur_dom,
                      string*         current_olig_seq,
                      input_prmtrs*   inp_prmtrs,
                      olig_domain*    neutral_domain,
                      float*          score,
                      float           best_score,
                      vector< olig >* bracket_oligs,
                      ofstream*       write_stat,
                      char            sep,
                      bool neutral_olig_test_flag = 0)
{
    bool olig_with_brac_link_flag;
    string current_bracket_seq;
    olig_domain* current_bracket_dom;

    for (int i = 0; i < (*bracket_oligs).size(); i++)
    {
        olig_with_brac_link_flag = 0;

        def_olig_seq_cmplr ( &( (*bracket_oligs)[i].dom_seq) ,
                             &current_bracket_seq,
                             1);

        if ( current_bracket_seq.length() == 0 )
            continue;

        for (int j = 0; j < (*bracket_oligs)[i].dom_seq.size(); j++)
        {
            current_bracket_dom = ( (*bracket_oligs)[i] ).dom_seq[j].olig_dom;

            if ( (*current_bracket_dom).name
                 ==
                 compl_name_to_cur_dom )
            {
                olig_with_brac_link_flag = 1;
                break;
            }
        }
        if ( olig_with_brac_link_flag )
        {
            (*write_stat) << "br ";

            (*score)
            +=
            dG_hairpin_test ( (*inp_prmtrs).hairpin_crit_dG,
                              (*inp_prmtrs).hairpin_length,
                              &current_bracket_seq,
                              (*inp_prmtrs).dna_flag,
                              write_stat, sep   );

            if ( score_test( (*score), best_score ) )
                return 1;

            (*write_stat) << "br ";

            (*score)
            +=
            dG_cmplx_test ( (*inp_prmtrs).cmplx_crit_dG,
                            //4 * (*inp_prmtrs).cmplx_crit_dG,
                            &current_bracket_seq,
                            &current_bracket_seq,
                            (*inp_prmtrs).dna_flag,
                           (*inp_prmtrs).cmplx_length,
                            write_stat,
                            sep       );

            if ( score_test( (*score), best_score ) )
                return 1;
        }
        else // presence link brack with olig should be defined
        {
            if ( neutral_olig_test_flag )
                continue;

            if ( olig_to_olig_link_detector( cur_olig,
                                             &( (*bracket_oligs)[i] ),
                                             (*neutral_domain).name   ) == 0 )
            {
                (*write_stat) << "br_";

                (*score)
                +=
                dG_cmplx_test ( (*inp_prmtrs).cmplx_crit_dG,
                                //4 * (*inp_prmtrs).cmplx_crit_dG,
                                &current_bracket_seq,
                                current_olig_seq,
                                (*inp_prmtrs).dna_flag,
                               (*inp_prmtrs).cmplx_length,
                                write_stat,
                                sep       );

                if ( score_test( (*score), best_score ) )
                    return 1;
            }
        }
    }
    return 0;
}


bool neutral_domain_maker( vector< olig >* defined_oligs,
                           vector< olig >* bracket_oligs,
                           olig_domain* neutral_domain,
                           input_prmtrs* inp_prmtrs,
                           unsigned long int* rndm_modifier,
                           ofstream* write_stat,
                           char sep)
{
    if ( (*neutral_domain).nucl_seq.length() != 0 )
        return 0;

    float current_score, // 0 is the best, but could be > 0
          best_score = 10000;

    int iter_nmb = 0;

    string best_seq;
    olig* fictive_olig;

    for (int i = 0; i < (*inp_prmtrs).max_iter_nmb_for_dmn_bld; i++)
    {
        cout << i << endl;

        current_score = 0;

        rndm_olig_gen ( (*inp_prmtrs).       dna_flag,
                        (*neutral_domain).   length,
                        (*inp_prmtrs).       GC_percentage,
                        &( (*neutral_domain).nucl_seq ),
                        rndm_modifier                      );

        if ( (*neutral_domain).nucl_seq.length() < 6 )
        {
            return 0;
        }

        (*write_stat) << endl;

        if ( def_oligs_cmptblt ( &best_seq,
                                 neutral_domain,
                                 inp_prmtrs,
                                 defined_oligs,
                                 &current_score,
                                 best_score,
                                 &( (*neutral_domain).nucl_seq ),
                                 write_stat,
                                 sep,
                                 1 )    )
            continue;

        if ( bracket_cmptblt( fictive_olig,
                              (*neutral_domain).name,
                              &( (*neutral_domain).nucl_seq ),
                              inp_prmtrs,
                              neutral_domain,
                              &current_score,
                              best_score,
                              bracket_oligs,
                              write_stat,
                              sep,
                              1)    )
            continue;

        best_score = current_score;

        best_seq = (*neutral_domain).nucl_seq;

        (*write_stat) << "best_domain_score: " << best_score << endl;

        if ( best_score == 0 )
            break;
    }

    (*neutral_domain).nucl_seq = best_seq;

    return 0;
}

bool inp_olig_cmptblt(olig*           cur_olig,
                      string*         current_olig_seq,
                      input_prmtrs*   inp_prmtrs,
                      olig_domain*    neutral_domain,
                      float*          score,
                      float           best_score,
                      vector< olig >* input_oligs,
                      ofstream*       write_stat,
                      char            sep)
{
    string cur_inp_olig_seq;

    for (int i = 0; i < (*input_oligs).size(); i++)
    {
        def_olig_seq_cmplr ( &( (*input_oligs)[i].dom_seq ),
                             &cur_inp_olig_seq,
                             1 );

        if ( cur_inp_olig_seq.length() == 0 )
            continue;

        if ( olig_to_olig_link_detector( cur_olig,
                                         &( (*input_oligs)[i] ),
                                         (*neutral_domain).name   ) == 0 )
        {
            (*write_stat) << "inp_";

            (*score)
            +=
            dG_cmplx_test ( (*inp_prmtrs).cmplx_crit_dG,
                                //4 * (*inp_prmtrs).cmplx_crit_dG,
                                &cur_inp_olig_seq,
                                current_olig_seq,
                                (*inp_prmtrs).dna_flag,
                                (*inp_prmtrs).cmplx_length,
                                write_stat,
                                sep       );

            if ( score_test( (*score), best_score ) )
                return 1;
        } else
        {
            (*write_stat) << "inp_";

            (*score)
            +=
            dG_hairpin_test ( (*inp_prmtrs).hairpin_crit_dG,
                              (*inp_prmtrs).hairpin_length,
                              &cur_inp_olig_seq,
                              (*inp_prmtrs).dna_flag,
                              write_stat, sep   );

            if ( score_test( (*score), best_score ) )
                return 1;
        }
    }
    return 0;
}

bool olig_cmtblt_tests (vector< vector< olig >* >* oligs_pntrs,
                        char            compl_cur_dom_name,
                        olig_domain*    neutral_domain,
                        input_prmtrs*   inp_prmtrs,
                        olig*           current_olig,
                        float*          current_score,
                        float           best_domain_score,
                        string*         current_olig_seq,
                        string*         compl_cur_dom,
                        ofstream*       write_stat,
                        char            sep)
{
    if ( self_olig_cmptblt ( (*neutral_domain).name,
                             inp_prmtrs,
                             current_olig,
                             current_score,
                             best_domain_score,
                             current_olig_seq,
                             write_stat,
                             sep) )
        return 1;

    if ( def_oligs_cmptblt ( compl_cur_dom,
                             neutral_domain,
                             inp_prmtrs,
                             (*oligs_pntrs)[0],
                             current_score,
                             best_domain_score,
                             current_olig_seq,
                             write_stat,
                             sep ) )
        return 1;

    if ( bracket_cmptblt( current_olig,
                          compl_cur_dom_name,
                          current_olig_seq,
                          inp_prmtrs,
                          neutral_domain,
                          current_score,
                          best_domain_score,
                          (*oligs_pntrs)[2],
                          write_stat,
                          sep)           )
        return 1;

    if ( inp_olig_cmptblt(current_olig,
                          current_olig_seq,
                          inp_prmtrs,
                          neutral_domain,
                          current_score,
                          best_domain_score,
                          (*oligs_pntrs)[3],
                          write_stat,
                          sep ) )
        return 1;

    return 0;
}

bool def_oligs_maker( olig_domain* neutral_domain,
                      vector<domain_pair>* domain_base,
                      input_prmtrs* inp_prmtrs,
                      vector< vector< olig >* >* oligs_pntrs)
{
    if ( ( *((*oligs_pntrs)[1]) ).size() == 0 )
        return 0;

    string current_olig_seq;
    string best_domain_variant;
    string* compl_nucl_seq;
    float best_domain_score,
          current_score;
    domain_ref current_domain_ref;
    olig* current_olig;
    unsigned long int rndm_modifier = 0;

    ofstream write_stat;
    write_stat.open("../output/debug_stat");
    char sep = '\t';

    neutral_domain_maker( (*oligs_pntrs)[0],
                          (*oligs_pntrs)[2],
                          neutral_domain,
                          inp_prmtrs,
                          &rndm_modifier,
                          &write_stat,
                          sep);

    bool break_flag;

    for (int i = 0; i < ( *((*oligs_pntrs)[1]) ).size(); i++)
    {
        current_olig = &( ( *((*oligs_pntrs)[1]) )[i] );

        for (int j = 0; j < ( *current_olig ).dom_seq.size(); j++)
        {
            write_stat << endl << "j = " << j << endl << endl;

            best_domain_score = 10000;

            current_domain_ref = ( *current_olig ).dom_seq[j];

            if ( ( *(current_domain_ref.olig_dom) ).nucl_seq.length() != 0 )

                continue;

            for (int k = 0; k < (*inp_prmtrs).max_iter_nmb_for_dmn_bld; k++)
            {
                cout << i << sep << j << sep << k << endl;

                write_stat << endl << "k = " << k << endl << endl;
                current_score = 0;
                break_flag = 0;

                rndm_olig_gen ( (*inp_prmtrs).dna_flag,
                                ( *(current_domain_ref.olig_dom) ).length,
                                (*inp_prmtrs).GC_percentage,
                                &( ( *(current_domain_ref.olig_dom) ).nucl_seq),
                                &rndm_modifier    );

                ( *(current_domain_ref.dom_pair) ).second_domain_maker( (*inp_prmtrs).dna_flag );
                //( *(current_domain_ref.dom_pair) ).complex_dG_calc( (*inp_prmtrs).dna_flag );
                //( *current_olig ).strongest_dG_calc( (*neutral_domain).name );

                def_olig_seq_cmplr ( &( (*current_olig).dom_seq ),
                                     &current_olig_seq );

                if ( current_olig_seq.length() < 6 )
                {
                    break_flag = 1;
                    break;
                }

                if ( olig_cmtblt_tests (oligs_pntrs,
                                        ( *(current_domain_ref.dom_pair) ).second.name,
                                        neutral_domain,
                                        inp_prmtrs,
                                        current_olig,
                                        &current_score,
                                        best_domain_score,
                                        &current_olig_seq,
                                        &( ( *(current_domain_ref.dom_pair) ).second.nucl_seq ),
                                        &write_stat,
                                        sep) )
                    continue;

                best_domain_score = current_score;
                best_domain_variant = ( *(current_domain_ref.olig_dom) ).nucl_seq;

                write_stat << "best_domain_score: " << best_domain_score << endl;

                if (best_domain_score == 0)
                {
                    break_flag = 1;
                    break;
                }
            }
            if (break_flag == 0)
            {
                ( *(current_domain_ref.olig_dom) ).nucl_seq = best_domain_variant;
                ( *(current_domain_ref.dom_pair) ).second_domain_maker( (*inp_prmtrs).dna_flag );
                //( *(current_domain_ref.dom_pair) ).complex_dG_calc( (*inp_prmtrs).dna_flag );

                write_stat << "best_domain_score: " << best_domain_score << endl
                           << "best_dom_variant: " << best_domain_variant << endl;

            }
            /*if (j == ( *current_olig ).dom_seq.size() - 1)
            {
                ( *current_olig ).strongest_dG_calc( (*neutral_domain).name );
            }*/
        }
        ( *((*oligs_pntrs)[0]) ).push_back( *current_olig );
    }
    return 0;
}
