#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <iomanip>
#include "my_structs.h"

using namespace std;

template<typename _DT_>
void write_vect_as_string (vector<_DT_>* vect,
                           ofstream* write,
                           char sep = '%'    )
{
    bool sep_flag = 0;

    if (sep != '%')
        sep_flag = 1;

    for (int i = 0; i < (*vect).size(); i++)
    {
        (*write) << (*vect)[i];

        if (sep_flag)
            (*write) << sep;
    }
}

void string_inverser (string* s);

void domain_writer(ofstream* write,
                   olig_domain* dom,
                   bool iverse_fl)
{
    string s = "_";

    if (iverse_fl)
        s.push_back('!');

    (*write) << s << (*dom).name;

    string seq;

    if( (*dom).nucl_seq.length() != 0 )
    {
        seq = (*dom).nucl_seq;

        if (iverse_fl)
        {
            string_inverser( &seq );
        }
        (*write) << '(' << seq << ')';
    }

    else
    {
        if ( (*dom).length != 0 )

            (*write) << '(' << (*dom).length << ')';
    }
}

void domain_base_writer (ofstream* write,
                         olig_domain* neutral_domain,
                         vector<domain_pair>* domain_base)
{
    (*write) << endl << "neutral_domain:" << endl << endl;

    domain_writer(write, neutral_domain, 0);

    (*write) << endl << endl << "domain_base:" << endl << endl;

    for (int i = 0; i < (*domain_base).size(); i++)
    {
        domain_writer(write, &( (*domain_base)[i].first ), 0 );

        if ( (*domain_base)[i].neutral_dom_flag == 0)

            domain_writer(write, &( (*domain_base)[i].second ), 0 );

        (*write) << endl;
    }
}

float dG_reader (string* seq, bool dna_flag);

float dG_and_struct_reader (string* seq,
                            string* seq_struct,
                            bool dna_flag);

struct olig_seq_and_name
{
    string seq;
    string name;
};

bool def_olig_seq_cmplr (vector <domain_ref>* seq_doms,
                         string* def_olig_nucl_seq,
                         bool continue_flag = 0);

void oligs_writer (bool dna_flag,
                   vector<olig_seq_and_name>* oligs_base,
                   ofstream* write,
                   vector< vector< olig >* >* oligs_pntrs)
{
    (*write) << endl << "oligs:" << endl << endl;

    domain_ref current_domain_ref;

    vector <domain_ref>* cur_dom_seq;

    olig_seq_and_name cur_olig;

    string cur_olig_struct;
    float dG;
    char sep = '\t';

    for (int i = 0; i < (*oligs_pntrs).size(); i++)
    {
        if (i == 1)
            continue;

        for (int j = 0; j < ( *( (*oligs_pntrs)[i] ) ).size(); j++)
        {
            (*write) << sep;

            cur_dom_seq = &( ( ( *( (*oligs_pntrs)[i] ) )[j] ).dom_seq );

            cur_olig.name.clear();

            for (int k = 0; k < ( *cur_dom_seq ).size(); k++)
            {
                current_domain_ref = ( *cur_dom_seq )[k];

                domain_writer( write,
                               current_domain_ref.olig_dom,
                               current_domain_ref.iverse_flag  );

                cur_olig.name.push_back( current_domain_ref.dom_name );
            }

            def_olig_seq_cmplr( cur_dom_seq, &(cur_olig.seq) );

            dG = dG_and_struct_reader( &(cur_olig.seq),
                                       &cur_olig_struct,
                                       dna_flag         );

            (*write) << endl
                     << sep << cur_olig.seq << endl
                     << sep << cur_olig_struct << endl
                     << sep << dG << endl << endl;

            (*oligs_base).push_back( cur_olig );
        }
        (*write) << endl;
    }
}

float aff_reader (string* seq_1, string* seq_2, bool dna_flag = 0);

void cross_aff_reader ( vector<olig_seq_and_name>* oligs_base,
                        ofstream* write,
                        bool dna_flag )
{
    char sep = '\t';
    int oligs_nmb = (int) (*oligs_base).size();

    for (int i = 0; i < oligs_nmb; i++)
    {
        (*write) << sep << (*oligs_base)[i].name;
    }

    float cross_aff [oligs_nmb][oligs_nmb];

    for (int i = 0; i < oligs_nmb; i++)
    {
        (*write) << endl
                 << (*oligs_base)[i].name;

        for (int j = i; j < oligs_nmb; j++)
        {
            cross_aff [i][j] = aff_reader( &( (*oligs_base)[i].seq ),
                                           &( (*oligs_base)[j].seq ),
                                           dna_flag );

            cross_aff [j][i] = cross_aff [i][j];
        }
        for (int j = 0; j < oligs_nmb; j++)
        {
            (*write) << sep << cross_aff [i][j];
        }
    }
}

void result_data_writer ( olig_domain* neutral_domain,
                          vector<domain_pair>* domain_base,
                          input_prmtrs* inp_prmtrs,
                          char     sep,
                          vector< vector< olig >* >* oligs_pntrs)
{
    const char* AAGS_result_file = "../output/AAGS_result";

    ofstream write( AAGS_result_file );
    write << setprecision(3);

    write << "dna_flag:"                 << sep << (*inp_prmtrs).dna_flag << endl
          << "max_iter_nmb_for_dmn_bld:" << sep << (*inp_prmtrs).max_iter_nmb_for_dmn_bld << endl
          << "hairpin_crit_dG:"          << sep << (*inp_prmtrs).hairpin_crit_dG << endl
          << "hairpin_length:"           << sep << (*inp_prmtrs).hairpin_length << endl
          << "cmplx_crit_dG:"            << sep << (*inp_prmtrs).cmplx_crit_dG << endl
          << "GC_percentage:"            << sep << (*inp_prmtrs).GC_percentage << endl;

    domain_base_writer (&write,
                        neutral_domain,
                        domain_base);

    vector<olig_seq_and_name> oligs_base;

    oligs_writer ( (*inp_prmtrs).dna_flag,
                   &oligs_base,
                   &write,
                   oligs_pntrs);

    cross_aff_reader( &oligs_base,
                      &write,
                      (*inp_prmtrs).dna_flag );
    write.close();
}
