#include <string>
#include <vector>
#include <cmath>

using namespace std;

struct two_pttrn_gluing
{
    float cmplx_dG_score;
    vector<int> appeared_pttrns_nmbs; //in order from 5' to 3'
};

int  string_in_base_finder (string* pttrn,
                            vector<string>* pttrn_base)
{
    for (int i = 0; i < (int)(*pttrn_base).size(); i++)
    {
        if ( (*pttrn) == (*pttrn_base)[i] )
            return i;
    }
    //cout << endl << "There's no such pattern in base" << endl;
    return -1;
}

bool appeared_pttrns_of_gluing_nmbs (vector<string>* pttrn_base,
                                     two_pttrn_gluing*  gluing_matrix_element,
                                     int i,
                                     int j)
{
    string appeared_pttrn;
    string gluing = ( (*pttrn_base)[i] ) + ( (*pttrn_base)[j] );
    gluing.erase( gluing.begin() );
    gluing.erase( gluing.begin() + gluing.length() - 1 );

    int pttrn_length = (int)( (*pttrn_base)[0] ).length();
    int appeared_pttrn_nmb;

    for (int k = 0; k < pttrn_length - 1; k++)
    {
        for (int l = k; l < k + pttrn_length; l++)
        {
            appeared_pttrn.push_back( gluing[l] );
        }
        appeared_pttrn_nmb = string_in_base_finder (&appeared_pttrn, pttrn_base);

        ( (*gluing_matrix_element).appeared_pttrns_nmbs ).push_back( appeared_pttrn_nmb );
        appeared_pttrn.clear();
    }
    return 0;
}

float dG_reader (string* seq, bool dna_flag);

float double_pttrn_score_calc (string* pttrn_1,
                               string* pttrn_2,
                               bool dna_flag,
                               float max_pttrn_cmplx_dG)
{
    string pttrn_self_cmplx = (*pttrn_1) + "+" + (*pttrn_2);
    return abs( dG_reader(&pttrn_self_cmplx, dna_flag)/max_pttrn_cmplx_dG );
}

bool gluing_matrix_maker (vector<string>* pttrn_base,
                          vector< vector<two_pttrn_gluing> >* gluing_matrix,
                          bool dna_flag,
                          float max_pttrn_cmplx_dG)
{
    two_pttrn_gluing gluing_matrix_element;
    vector<two_pttrn_gluing> gluing_matrix_string;

    for (int i = 0; i < (*pttrn_base).size(); i++) // string in gluing_matrix
    {
        for (int j = 0; j < (*pttrn_base).size(); j++) //column in gluing_matrix
        {
            gluing_matrix_element.cmplx_dG_score
            =
            double_pttrn_score_calc ( &( (*pttrn_base)[i] ),
                                      &( (*pttrn_base)[j] ),
                                      dna_flag,
                                      max_pttrn_cmplx_dG);

            appeared_pttrns_of_gluing_nmbs (pttrn_base,
                                            &gluing_matrix_element,
                                            i,
                                            j);

            gluing_matrix_string.push_back(gluing_matrix_element);
            (gluing_matrix_element.appeared_pttrns_nmbs).clear();
        }
        (*gluing_matrix).push_back(gluing_matrix_string);
        gluing_matrix_string.clear();
    }
    return 0;
}
