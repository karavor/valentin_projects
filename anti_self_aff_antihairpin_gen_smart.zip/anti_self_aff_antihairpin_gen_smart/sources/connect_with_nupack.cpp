#include <string>
#include <fstream>
#include <cstdlib>

using namespace std;

#define MFE_FUNC_DNA "\
    #/bin/bash \n\
    export NUPACKHOME=/home/valentin/work_backup/nupack \n\
    $NUPACKHOME/bin/mfe -material dna $PWD/input/input_seq \n\
"

#define MFE_FUNC_RNA "\
    #/bin/bash \n\
    export NUPACKHOME=/home/valentin/work_backup/nupack \n\
    $NUPACKHOME/bin/mfe -material rna $PWD/input/input_seq \n\
"

#define CLEAN_FUNC "\
    #/bin/bash \n\
    rm $PWD/input/input_seq.in \n\
    rm $PWD/input/input_seq.mfe \n\
"

float decimal_numb_reader( string* s );

float dG_reader (string* seq, bool dna_flag)
{
    const char* input_mfe     = "./input/input_seq.in";
    const char* output_mfe    = "./input/input_seq.mfe";

    ofstream w;
    w.open(input_mfe);
    w << *seq;
    w.close();

    if (dna_flag)
         system(MFE_FUNC_DNA);
    else system(MFE_FUNC_RNA);

    string temporal_str;

    ifstream r;
    r.open(output_mfe);

    for (int i = 0; i < 15; i++)
    {
        getline(r, temporal_str);
    }

    if (temporal_str.length() == 0)
        return 0;

    return decimal_numb_reader( &temporal_str);
}

int main()
{
    return 0;
}
