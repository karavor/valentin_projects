#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "main.h"
//#include <iomanip>

using namespace std;
 // text file input should exist

float max_pttrn_cmplx_dG_calc (int pttrn_length, bool dna_flag)
{
    string worst_pttrn_cmplx;

    for (int i = 0; i < pttrn_length; i++)
    {
        worst_pttrn_cmplx.push_back('C');
    }
    worst_pttrn_cmplx.push_back('+');

    for (int i = 0; i < pttrn_length; i++)
    {
        worst_pttrn_cmplx.push_back('G');
    }
    return dG_reader(&worst_pttrn_cmplx, dna_flag);
}

struct two_pttrn_gluing
{
    float cmplx_dG_score;
    vector<int> appeared_pttrns_nmbs; //in order from 5' to 3'
};
/*
template<class _T_>

void vect_vect_mem_free (vector< vector<_T_> >* vect_vect)
{
    for (int i = 0; i < (*vect_vect).size(); i++)
    {
        ((*vect_vect)[i]).clear();
    }
    (*vect_vect).clear();
}
*/
struct A_n_k_elmnt_with_nmb
{
    unsigned short int nmb;
    vector<unsigned short int> elmnt;
};

template<typename _DT_>
void write_vect_as_string (vector<_DT_>* vect,
                           ofstream* write    )
{
    for (int i = 0; i < (*vect).size(); i++)
    {
        (*write) << (*vect)[i];
    }
}

void result_data_writer (vector< A_n_k_elmnt_with_nmb >* final_oligs_base)
{
    const char* AAGS_result_file   = "../output/AAGS_result";

    ofstream write;
    write.open( AAGS_result_file );

    for (int i = 0; i < (*final_oligs_base).size(); i++)
    {
        write_vect_as_string<int>( &((*final_oligs_base)[i].elmnt), &write );
        write << endl;
    }

    write.close();
}

int main()
{
    bool  dna_flag;
    int   pttrn_length,
          pttrn_nmb_in_olig;
    float crit_score;

    input_data_reader (& dna_flag,
                       & pttrn_length,
                       & pttrn_nmb_in_olig,
                       & crit_score,
                       ' ');

    float max_pttrn_cmplx_dG = max_pttrn_cmplx_dG_calc (pttrn_length, dna_flag);

    vector<string> pttrn_base;
    pttrn_base_generator (&pttrn_base,
                          pttrn_length,
                          dna_flag,
                          max_pttrn_cmplx_dG);

    vector< vector<two_pttrn_gluing> > gluing_matrix; //like column of the strings

    gluing_matrix_maker (&pttrn_base,
                         &gluing_matrix,
                         dna_flag,
                         max_pttrn_cmplx_dG);

    vector< A_n_k_elmnt_with_nmb > final_oligs_base;

    modified_A_n_k_maker ( pttrn_base.size(),
                           pttrn_nmb_in_olig,
                           &final_oligs_base,
                           crit_score,
                           &gluing_matrix );

    result_data_writer (&final_oligs_base);

    return 0;
}
