#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

const char* test_output    = "./test_output";

int int_pow (int n, int power)
{
    int result = 1;

    for (int i = 0; i < power; i++)
        result *= n;

    return result;
}

struct A_n_k_elmnt_with_nmb
{
    unsigned short int nmb;
    vector<unsigned short int> elmnt;
};

struct two_pttrn_gluing
{
    float cmplx_dG_score;
    vector<int> appeared_pttrns_nmbs; //in order from 5' to 3'
};

bool A_n_k_elmnt_init_test ( A_n_k_elmnt_with_nmb* A_n_k_elmnt,
                             float crit_score,
                             vector< vector<two_pttrn_gluing> >* gluing_matrix )
{
    int current_pttrn_nmb = (*A_n_k_elmnt).elmnt[ (*A_n_k_elmnt).elmnt.size() - 1 ];

    if ( (*gluing_matrix)[current_pttrn_nmb][current_pttrn_nmb].cmplx_dG_score > crit_score )
    {
        return 0;
    }

    return 1;
}

template<class _T_>

bool C_n_k_generator (vector<_T_>* elements_arr,
                      vector< vector<_T_> >* result_arr,
                      int k)
{
    (*result_arr).clear();
    int n = (*elements_arr).size();

    if (n < k)
        return 1;

    vector<_T_> current_res;

    for (int j = 0; j <= n - k; j++)
    {
        for (int l = j; l < j + k; l++)
            current_res.push_back( (*elements_arr)[l] );

        (*result_arr).push_back(current_res);

        for (int i = j + k; i < n; i++)
        {
            current_res.erase(current_res.begin() + k - 1);
            current_res.push_back( (*elements_arr)[i] );
            (*result_arr).push_back(current_res);
        }
        current_res.clear();
    }
    return 0;
}

bool A_n_k_elmnt_test ( A_n_k_elmnt_with_nmb* A_n_k_elmnt,
                        float crit_score,
                        vector< vector<two_pttrn_gluing> >* gluing_matrix )
{
    int last_in_A_n_k_elmnt_pttrn_nmb
        =
        (*A_n_k_elmnt).elmnt[ (*A_n_k_elmnt).elmnt.size() - 1 ];

    int last_to_last_in_A_n_k_elmnt_pttrn_nmb
        =
        (*A_n_k_elmnt).elmnt[ (*A_n_k_elmnt).elmnt.size() - 2 ];

    two_pttrn_gluing current_gluing_matrix_elmnt
    =
    (*gluing_matrix)[last_to_last_in_A_n_k_elmnt_pttrn_nmb]
                    [    last_in_A_n_k_elmnt_pttrn_nmb    ];

    vector<int> new_appeared_pttrns_nmbs;

    for (int i = 0; i < current_gluing_matrix_elmnt.
                        appeared_pttrns_nmbs.size(); i++)
    {
        new_appeared_pttrns_nmbs.push_back

        ( current_gluing_matrix_elmnt.appeared_pttrns_nmbs[i] );
    }

    new_appeared_pttrns_nmbs.push_back(last_in_A_n_k_elmnt_pttrn_nmb);

    for (int i = 0; i < new_appeared_pttrns_nmbs.size(); i++)
    {
        if ( (*gluing_matrix)[ new_appeared_pttrns_nmbs[i] ]
                             [ new_appeared_pttrns_nmbs[i] ].cmplx_dG_score > crit_score )

        {
            return 0;
        }

        for (int j = 0; j < (*A_n_k_elmnt).elmnt.size() - 1; j++)
        {
            if ( (*gluing_matrix)[ new_appeared_pttrns_nmbs[i] ]
                                 [   (*A_n_k_elmnt).elmnt[j]   ].cmplx_dG_score > crit_score )
            {
                return 0;
            }

            for (int k = 0; k < new_appeared_pttrns_nmbs.size(); k++)
            {
                if ( j == ((*A_n_k_elmnt).elmnt.size() - 1) )

                    continue;

                if ( (*gluing_matrix)[ new_appeared_pttrns_nmbs[i] ]
                                     [   (*gluing_matrix)[ (*A_n_k_elmnt).elmnt[  j  ] ]
                                                         [ (*A_n_k_elmnt).elmnt[j + 1] ].appeared_pttrns_nmbs[k] ].cmplx_dG_score > crit_score )
                {
                    return 0;
                }
            }
        }
    }
    vector< vector<int> > C_n_k_new_appeared_pttrns_nmbs;

    C_n_k_generator<int> (&new_appeared_pttrns_nmbs, &C_n_k_new_appeared_pttrns_nmbs, 2);

    for (int i = 0; i < C_n_k_new_appeared_pttrns_nmbs.size(); i++)
    {
        if ( (*gluing_matrix)[ C_n_k_new_appeared_pttrns_nmbs[i][0] ]
                             [ C_n_k_new_appeared_pttrns_nmbs[i][1] ].cmplx_dG_score > crit_score )
        {
            return 0;
        }
    }

    return 1;
}

bool forbidden_A_n_k_elmnt_nmb_test( unsigned short int n,
                                     unsigned short int current_A_n_k_elmnt_nmb,
                                     vector< vector<unsigned short int> >* forbidden_A_n_k_elmnts_nmbs_stat )
{
    for (int i = 0; i < (*forbidden_A_n_k_elmnts_nmbs_stat).size(); i++)
    {
        for (int j = 0; j < (*forbidden_A_n_k_elmnts_nmbs_stat)[i].size(); j++)
        {
            if ( ( current_A_n_k_elmnt_nmb -
                   (*forbidden_A_n_k_elmnts_nmbs_stat)[i][j] ) % int_pow(n, i + 1) == 0 )
            {
                return 0;
            }
        }
    }
    return 1;
}
/*
template<typename _DT_>
void write_vect_as_string (vector<_DT_>* vect,
                           ofstream* write    )
{
    for (int i = 0; i < (*vect).size(); i++)
    {
        (*write) << (*vect)[i];
    }
}

void A_n_k_maker_stat_writer ( ofstream* write,
                               int iter_nmb,
                               vector< A_n_k_elmnt_with_nmb >* A_n_k,
                               vector< vector<unsigned short int> >*
                                     forbidden_A_n_k_elmnts_nmbs_stat)
{
    (*write) << endl << iter_nmb << endl << endl;

    char sep = '\t';

    for (int i = 0; i < (*A_n_k).size(); i++)
    {
        (*write) << sep << (*A_n_k)[i].nmb << sep;

        write_vect_as_string <unsigned short int> ( &((*A_n_k)[i].elmnt),
                                                     write                );
        (*write) << endl;
    }
    (*write) << endl;

    for (int j = 0; j < (*forbidden_A_n_k_elmnts_nmbs_stat)[iter_nmb].size(); j++)
    {
        (*write) << sep << (*forbidden_A_n_k_elmnts_nmbs_stat)[iter_nmb][j] << endl;
    }
}
*/
void dead_end_A_n_k_elmnts_nmbs_add (int  n,
                                     int  i,
                                     int  A_n_k_insert_nmb_nmb,
                                     int* last_erased_elmnt_nmb,
                                     int  fix_arr_size,
                                     int  iter_nmb,
                                     vector< vector<unsigned short int> >*
                                     forbidden_A_n_k_elmnts_nmbs_stat)
{
    if ( (i == 0) && ( A_n_k_insert_nmb_nmb > 0) )
    {
        (*last_erased_elmnt_nmb) = -1;
    }

    if ( (i == (fix_arr_size - 1))
        &&
         ( A_n_k_insert_nmb_nmb < (int_pow(n, iter_nmb) - 1) ) )
    {
        for (int j = ( A_n_k_insert_nmb_nmb + 1 ) * n;
                 j < int_pow(n, iter_nmb)               * n; j++)
        {
            (*forbidden_A_n_k_elmnts_nmbs_stat)
            [(*forbidden_A_n_k_elmnts_nmbs_stat).size() - 1].
            push_back( j );
        }
    }

    if ( ( A_n_k_insert_nmb_nmb - 1 ) > (*last_erased_elmnt_nmb) )
    {
        for (int j = ((*last_erased_elmnt_nmb) + 1) * n;
                 j < A_n_k_insert_nmb_nmb           * n; j++)
        {
            (*forbidden_A_n_k_elmnts_nmbs_stat)
            [(*forbidden_A_n_k_elmnts_nmbs_stat).size() - 1].
            push_back( j );
        }
    }
}

void A_n_k_arr_init (int n,
                     vector< A_n_k_elmnt_with_nmb >* A_n_k,
                     vector< vector<unsigned short int> >*
                     forbidden_A_n_k_elmnts_nmbs_stat,
                     float crit_score,
                     vector< vector<two_pttrn_gluing> >* gluing_matrix)
{
    A_n_k_elmnt_with_nmb current_A_n_k_elmnt;
    vector<unsigned short int> init_vect;

    (*forbidden_A_n_k_elmnts_nmbs_stat).push_back(init_vect);

    for (unsigned short int i = 0; i < n; i++) // arr initialisation
    {
        current_A_n_k_elmnt.elmnt.push_back(i);
        current_A_n_k_elmnt.nmb = i;

        if ( A_n_k_elmnt_init_test( &current_A_n_k_elmnt,
                                    crit_score,
                                    gluing_matrix        ) )
        {
            (*A_n_k).push_back(current_A_n_k_elmnt);
        }
        else (*forbidden_A_n_k_elmnts_nmbs_stat)
             [(*forbidden_A_n_k_elmnts_nmbs_stat).size() - 1].
             push_back( current_A_n_k_elmnt.nmb );

        current_A_n_k_elmnt.elmnt.clear();
    }
}

bool modified_A_n_k_maker ( unsigned short int n,
                            unsigned short int k,
                            vector< A_n_k_elmnt_with_nmb >* A_n_k,
                            float crit_score,
                            vector< vector<two_pttrn_gluing> >* gluing_matrix )
{
    if ( n < k )
        return 1;

    vector< vector<unsigned short int> > forbidden_A_n_k_elmnts_nmbs_stat;

    A_n_k_arr_init (n,
                    A_n_k,
                    &forbidden_A_n_k_elmnts_nmbs_stat,
                    crit_score,
                    gluing_matrix);

/*    ofstream write;
    write.open(test_output);

    A_n_k_maker_stat_writer(&write,
                            0,
                            A_n_k,
                            &forbidden_A_n_k_elmnts_nmbs_stat);
*/
    int fix_arr_size;
    int insert_nmb;
    int last_erased_elmnt_nmb;
    A_n_k_elmnt_with_nmb current_A_n_k_elmnt;
    vector<unsigned short int> init_vect;

    for (int iter_nmb = 1; iter_nmb < k; iter_nmb++)
    {
        insert_nmb = 0;
        current_A_n_k_elmnt.nmb = 0;
        last_erased_elmnt_nmb = 0;

        fix_arr_size = (*A_n_k).size();

        forbidden_A_n_k_elmnts_nmbs_stat.push_back(init_vect);

        for (int i = 0; i < fix_arr_size; i++)
        {
            current_A_n_k_elmnt.elmnt = ((*A_n_k)[insert_nmb]).elmnt;

            current_A_n_k_elmnt.nmb = n * ((*A_n_k)[insert_nmb]).nmb;

            dead_end_A_n_k_elmnts_nmbs_add (n,
                                            i,
                                            ((*A_n_k)[insert_nmb]).nmb,
                                            &last_erased_elmnt_nmb,
                                            fix_arr_size,
                                            iter_nmb,
                                            &forbidden_A_n_k_elmnts_nmbs_stat);

            last_erased_elmnt_nmb = ((*A_n_k)[insert_nmb]).nmb;

            (*A_n_k).erase( (*A_n_k).begin() + insert_nmb );

            for (int j = 0; j < n; j++)
            {
                if ( forbidden_A_n_k_elmnt_nmb_test( n,
                                                     current_A_n_k_elmnt.nmb,
                                                     &forbidden_A_n_k_elmnts_nmbs_stat ) )
                {
                    current_A_n_k_elmnt.elmnt.push_back(j);

                    if ( A_n_k_elmnt_test( &current_A_n_k_elmnt,
                                           crit_score,
                                           gluing_matrix        ) )
                    {
                        (*A_n_k).insert( (*A_n_k).begin() + insert_nmb,
                                  current_A_n_k_elmnt);
                        insert_nmb ++;
                    }
                    else forbidden_A_n_k_elmnts_nmbs_stat
                         [forbidden_A_n_k_elmnts_nmbs_stat.size() - 1].
                         push_back( current_A_n_k_elmnt.nmb );

                    current_A_n_k_elmnt.elmnt.pop_back();
                }

                current_A_n_k_elmnt.nmb ++;
            }
        }/*
        A_n_k_maker_stat_writer(&write,
                                iter_nmb,
                                A_n_k,
                                &forbidden_A_n_k_elmnts_nmbs_stat);*/
    }
    //write.close();
    return 0;
}
