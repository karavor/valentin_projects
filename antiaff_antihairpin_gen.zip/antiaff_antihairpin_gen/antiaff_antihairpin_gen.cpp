#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <vector>
#include <cmath>

using namespace std;
const char* initial_oligs = "../antiaff_antihairpin_gen_smart/output/AAGS_caller_stat";
const char* input_file    = "./input/AAG_input"; // text file input should exist
const char* input_antihairpin_dG_simple =  "../antihairpin_dG_simple/input/input";
const char* output_antihairpin_dG_simple = "../antihairpin_dG_simple/output/result";
const char* input_aff_to_group_reducer_simple = "../aff_to_group_reducer_simple/input/input";
const char* output_aff_to_group_reducer_simple = "../aff_to_group_reducer_simple/output/result";
const char* output_file   = "./AAG_result";
const char* conc_input    = "./input/complex.in"; // file complex.con should exist
const char* conc_output   = "./input/complex.eq";
const char* input_mfe     = "./input/input_seq.in";
const char* output_mfe    = "./input/input_seq.mfe";
//const char* statistic     = "./output/statistic";


int pause;

int int_pow (int n, int power)
{
    int result = 1;

    for (int i = 0; i < power; i++)
        result *= n;

    return result;
}

int int_numb_reader (string* s)
{
    int result = 0;
    int ten_pow = 0;
    int minus_flag = 1;

    if ( (*s)[0] == '-' )
    {
        minus_flag = -1;
        (*s).erase( (*s).begin(), (*s).begin() + 1 );
    }

    for (int i = (*s).length() - 1; i >= 0 ; i--)
    {
        result += ( (int)(*s)[i] - (int)'0' ) * int_pow (10, ten_pow);
        ten_pow++;
    }
    return result * minus_flag;
}

float decimal_numb_reader( string* s )
{
    int minus_flag = 1;
    if ( (*s)[0] == '-' )
    {
        minus_flag = -1;
        (*s).erase( (*s).begin(), (*s).begin() + 1 );
    }
    size_t dot_position = (*s).find('.');
    if ( dot_position == (*s).npos )
    {
        return (float)int_numb_reader(s) * (float)minus_flag;
    }
    string int_part;

    for (int i = 0; i < (int)dot_position ; i++)
        int_part.push_back( (*s)[i] );

    (*s).erase( (*s).begin(), (*s).begin() + dot_position + 1 ); //in s now is real part

    return (float) minus_flag * ( (float)int_numb_reader(&int_part) + (float)int_numb_reader(s) / (float)int_pow (10, (*s).length() ) );
}

float exp_numb_reader (string* s)
{
    size_t exp_position = (*s).find('e');

    if ( exp_position == (*s).npos )
    {
        exp_position = (*s).find('E');
        if ( exp_position == (*s).npos )
            return decimal_numb_reader(s);
    }
    int minus_exp_flag = 1;

    if ( (*s)[exp_position + 1]  == '-' )
        minus_exp_flag = -1;

    string mantissa;

    for (int i = 0; i < (int)exp_position ; i++)
        mantissa.push_back( (*s)[i] );

    (*s).erase( (*s).begin(), (*s).begin() + exp_position + 1 );

    if ( (*s)[0] == '+' || (*s)[0] == '-')
        (*s).erase( (*s).begin(), (*s).begin() + 1 );

    int exp_part = int_numb_reader(s);

    return decimal_numb_reader(&mantissa) * pow(10.0, exp_part * minus_exp_flag);
}

#define antihairpin_dG_simple_call "\
    #/bin/bash \n\
    cd ../antihairpin_dG_simple \n\
    ./antihairpin_dG_simple \n\
"

#define aff_to_group_reducer_simple_call "\
    #/bin/bash \n\
    cd ../aff_to_group_reducer_simple \n\
    ./aff_to_group_reducer_simple \n\
"

#define MFE_FUNC "\
    #/bin/bash \n\
    export NUPACKHOME=/home/valentin/work_backup/nupack \n\
    $NUPACKHOME/bin/mfe $PWD/input/input_seq \n\
"

#define CONCENTRATIONS_FUNC "\
    #/bin/bash \n\
    export NUPACKHOME=/home/valentin/work_backup/nupack \n\
    $NUPACKHOME/bin/complexes -T 23 -material rna -quiet $PWD/input/complex \n\
    $NUPACKHOME/bin/concentrations -quiet $PWD/input/complex \n\
"

#define CONCENTRATIONS_FUNC_DNA "\
    #/bin/bash \n\
    export NUPACKHOME=/home/valentin/work_backup/nupack \n\
    $NUPACKHOME/bin/complexes -T 23 -material dna $PWD/input/complex \n\
    $NUPACKHOME/bin/concentrations $PWD/input/complex \n\
"

#define CLEAN_FUNC "\
    #/bin/bash \n\
    rm $PWD/input/input_seq.in \n\
    rm $PWD/input/input_seq.mfe \n\
    rm $PWD/input/complex.in \n\
    rm $PWD/input/complex.eq \n\
    rm $PWD/input/complex.cx \n\
"

float dG_reader (string* seq)
{
    ofstream w;
    w.open(input_mfe);
    w << *seq;
    w.close();

    system(MFE_FUNC);

    string dG_str;

    ifstream r;
    r.open(output_mfe);

    do    {getline(r, dG_str);}
    while (dG_str[0] != '-' &&
           dG_str[0] != '0'    );

    return decimal_numb_reader(&dG_str);
}

float aff_reader (string* seq_1, string* seq_2, int dna_flag = 0)
{
    ofstream w;
    w.open(conc_input);
    w << 2        << endl
      << (*seq_1) << endl
      << (*seq_2) << endl
      << 2;
    w.close();
    if (dna_flag)
        system(CONCENTRATIONS_FUNC_DNA);
    else system(CONCENTRATIONS_FUNC);

    string temp_str;
    ifstream r;
    r.open(conc_output);

    do getline(r, temp_str);
    while (temp_str[0] == '%');

    while (temp_str[2] != temp_str[4])
        getline(r, temp_str);

    r.close();
    string aff_str;

    for(int i = 20; i < temp_str.length(); i++)
        aff_str.push_back(temp_str[i]);

    float aff = exp_numb_reader(&aff_str);
    return (aff/1e-06)*100;
}

char complement_ncltd (char ncltd, int dna_flag)
{
    switch(ncltd)
    {
        case 'C':
            return 'G';
        case 'G':
            return 'C';
        case 'A':
            if (dna_flag)
                return 'T';
            return 'U';
        case 'U':
            return 'A';
        case 'T':
            return 'A';
    }
    return 'E';
}

void string_inverser (string* s)
{
    string s_copy = (*s);
    int l = (*s).length();
    for (int i = 0; i < l; i++ )
    {
        (*s)[i] = s_copy[l-1-i];
    }
}

int c_seq_maker (string* seq, string* c_seq, int dna_flag)
{
    int l = (*seq).length();
    for (int i = 0; i < l; i++ )
    {
        switch((*seq)[i])
        {
            case 'C':
                (*c_seq).push_back('G');
                break;
            case 'G':
                (*c_seq).push_back('C');
                break;
            case 'A':
                if (dna_flag)
                     (*c_seq).push_back('T');
                else (*c_seq).push_back('U');
                break;
            case 'U':
                (*c_seq).push_back('A');
                break;
            case 'T':
                (*c_seq).push_back('A');
                break;
        }
    }
    string_inverser(c_seq);
    return 0;
}

char random_ncltd (int dna_flag, int rnd_seed)
{
    srand (rnd_seed);
    int random_int = rand() % 6;

    if (random_int <= 1)
        return 'A';

    if (random_int <= 3)
    {
        if (dna_flag)
            return 'T';
        return 'U';
    }
    if (random_int == 4)
        return 'C';

    return 'G';
}

void olig_generator (int olig_length,
                     string* olig_seq,
                     int dna_flag,
                     int rndm_modifier = 0)
{
    for (int i = 0; i < olig_length; i++)

        (*olig_seq).push_back( random_ncltd(dna_flag, time(NULL) + i + rndm_modifier) );
}

int  antihairpin_maker (string* input_seq,
                        float target_dG,
                        float target_dG_accuracy,
                        int dna_flag)
{
    ofstream write;
    write.open(input_antihairpin_dG_simple);
    write << (*input_seq) << ' '
         << target_dG << ' '
         << target_dG_accuracy << ' '
         << dna_flag;
    write.close();

    system(antihairpin_dG_simple_call);

    ifstream read;
    read.open(output_antihairpin_dG_simple);
    string temp_str;
    getline(read, temp_str);
    getline(read, temp_str);
    read.close();

    if (temp_str[temp_str.length() - 1] == '+')
    {
        (*input_seq).clear();
        for (int i = 0; temp_str[i] != '\t'; i++)
            (*input_seq).push_back(temp_str[i]);
        return 1;
    }
    return 0;
}

int aff_to_group_reducer_maker (int     dna_flag,
                                string* olig_seq,
                                int     oligs_nmb,
                                float   limit_aff_to_each_olig_from_group,
                                vector<string>* oligs_group,
                                float   limit_olig_dG,
                                vector<string>* stat,
                                float* f_stat,
                                float limit_cmplx_with_complement_part_dG,
                                float limit_complement_part_dG,
                                float limit_complement_cross_aff          )
{
    ofstream write;
    write.open(input_aff_to_group_reducer_simple);
    write << "DNA_flag: " << dna_flag << endl
          << "input_olig: " << (*olig_seq) << endl
          << "oligs_nmb: " << oligs_nmb << endl
          << "min_aff_level_to_each_olig_from_group: " << limit_aff_to_each_olig_from_group;

    for (int i = 1; i <= oligs_nmb; i++)
        write << endl << i << ") " <<  (*oligs_group)[i-1];

    write.close();

    system(aff_to_group_reducer_simple_call);

    ifstream read;
    read.open(output_aff_to_group_reducer_simple);

    getline(read, *olig_seq);

    string temp_str;
    float olig_dG;
    getline(read, temp_str);
    (*stat)[0] = temp_str;
    temp_str.erase( temp_str.begin(), temp_str.begin() +
                                      temp_str.find('=') + 2);
    olig_dG = decimal_numb_reader(&temp_str);

    getline(read, temp_str);
    getline(read, temp_str);

    for (int i = 0; i <= oligs_nmb; i++)
    {
        getline(read, temp_str);
        (*stat)[i + 1] = temp_str;
        if (temp_str[temp_str.length() - 1] == '-')
            return -1;
    }
    read.close();

    string olig_seq_1,
           c_olig_seq_1,
           olig_seq_2,
           c_olig_seq_2;

    for (int k = 0; k < (int) ( (*olig_seq).length() / 2 ); k++)
        olig_seq_1.push_back( (*olig_seq)[k] );

    for (int k = olig_seq_1.length(); k < (*olig_seq).length(); k++)
        olig_seq_2.push_back( (*olig_seq)[k] );

    c_seq_maker(&olig_seq_1, &c_olig_seq_1, dna_flag);
    c_seq_maker(&olig_seq_2, &c_olig_seq_2, dna_flag);

    string cmplx_1 = olig_seq_1 + "+" + c_olig_seq_1;
    string cmplx_2 = olig_seq_2 + "+" + c_olig_seq_2;

    f_stat[0] = aff_reader(&olig_seq_1, &c_olig_seq_2, dna_flag);
    f_stat[1] = aff_reader(&olig_seq_2, &c_olig_seq_1, dna_flag);
    f_stat[2] = dG_reader(&cmplx_1);
    f_stat[3] = dG_reader(&cmplx_2);
    f_stat[4] = dG_reader(&c_olig_seq_1);
    f_stat[5] = dG_reader(&c_olig_seq_2);

    if ( f_stat[0] > limit_complement_cross_aff ||
         f_stat[1] > limit_complement_cross_aff ||
         f_stat[2] > limit_cmplx_with_complement_part_dG ||
         f_stat[3] > limit_cmplx_with_complement_part_dG ||
         f_stat[4] < limit_complement_part_dG ||
         f_stat[5] < limit_complement_part_dG              )
    {
        return -1;
    }

    if (olig_dG < limit_olig_dG)
        return -2;

    return 1;
}

void string_with_float_prmtr_reader(ifstream* read, float* prmtr)
{
    string read_str;
    getline( (*read), read_str);
    read_str.erase( read_str.begin(), read_str.begin() + read_str.find( ' ' ) + 1 );
    *prmtr = decimal_numb_reader(&read_str);
}

void string_with_int_prmtr_reader(ifstream* read, int* prmtr)
{
    string read_str;
    getline( (*read), read_str);
    read_str.erase( read_str.begin(), read_str.begin() + read_str.find( ' ' ) + 1 );
    *prmtr = int_numb_reader(&read_str);
}

int main()
{
    int dna_flag,
        oligs_nmb;

    float target_dG,
          target_dG_accuracy,
          limit_aff_to_each_olig_from_group,
          limit_cmplx_with_complement_part_dG,
          limit_complement_part_dG,
          limit_complement_cross_aff;

    vector<string> oligs_group(0);

    string read_str;
    ifstream read;
    read.open(input_file);

    string_with_int_prmtr_reader(&read, &dna_flag);
    string_with_float_prmtr_reader(&read, &target_dG);
    string_with_float_prmtr_reader(&read, &target_dG_accuracy);
    string_with_int_prmtr_reader(&read, &oligs_nmb);
    string_with_float_prmtr_reader(&read, &limit_aff_to_each_olig_from_group);
    string_with_float_prmtr_reader(&read, &limit_cmplx_with_complement_part_dG);
    string_with_float_prmtr_reader(&read, &limit_complement_part_dG);
    string_with_float_prmtr_reader(&read, &limit_complement_cross_aff);

    for (int i = 0; i < oligs_nmb; i++)
    {
        getline(read, read_str);
        read_str.erase( read_str.begin(), read_str.begin() +
                                          read_str.find( ' ' ) + 1 );
        oligs_group.push_back(read_str);
    }

    read.close();

    read.open(initial_oligs);
    string olig_seq;

    ofstream write;
    write.open(output_file);

    int break_flag;

    vector<string> stat(oligs_nmb + 2);
    float f_stat[6];

    while ( !read.eof() )
    {
        getline(read, olig_seq);
        olig_seq.erase( olig_seq.begin() + olig_seq.find( ' ' ),
                        olig_seq.end());

        for (int j = 0; j < 10; j++)
        {
            break_flag = 0;

            if ( antihairpin_maker (&olig_seq,
                                    target_dG,
                                    target_dG_accuracy,
                                    dna_flag)          == 0 )
                break;

            switch( aff_to_group_reducer_maker (dna_flag,
                                                &olig_seq,
                                                oligs_nmb,
                                                limit_aff_to_each_olig_from_group,
                                                &oligs_group,
                                                target_dG - target_dG_accuracy,
                                                &stat,
                                                f_stat,
                                                limit_cmplx_with_complement_part_dG,
                                                limit_complement_part_dG,
                                                limit_complement_cross_aff          ) )
            {
                case 1:
                    write << olig_seq;

                    for (int k = 0; k < (int)stat.size(); k++)
                        write << endl << stat[k];

                    write << endl << "cross_aff_1_2: " << f_stat[0]
                          << endl << "cross_aff_2_1: " << f_stat[1]
                          << endl << "complement_part_cmplx_dG_1: " << f_stat[2]
                          << endl << "complement_part_cmplx_dG_2: " << f_stat[3]
                          << endl << "complement_part_dG_1: " << f_stat[4]
                          << endl << "complement_part_dG_2: " << f_stat[5];

                    write.close();
                    system(CLEAN_FUNC);
                    return 0;
                case -1:
                    break_flag = 1;
            }
            if (break_flag)
                break;
        }
    }
    write << "fail";
    write.close();
    system(CLEAN_FUNC);
    return 0;
}
