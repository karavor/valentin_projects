#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <cmath>

using namespace std;
const char* input_file    = "./AAG_input"; // text file input should exist
const char* input_antihairpin_dG_simple =  "../antihairpin_dG_simple/input/input";
const char* output_antihairpin_dG_simple = "../antihairpin_dG_simple/output/result";
const char* input_aff_to_group_reducer_simple = "../aff_to_group_reducer_simple/input/input";
const char* output_aff_to_group_reducer_simple = "../aff_to_group_reducer_simple/output/result";
const char* output_file   = "./AAG_result";
//const char* statistic     = "./output/statistic";


int pause;

int decimal_numb_reader( string* s, int str_position, float* numb, int minus_flag = 0 )
{
    (*numb) = 0;
    int i = str_position;

    if ( (*s)[i] == '-' )
        return decimal_numb_reader ( s, str_position + 1, numb, 1 );

    int s_length = (*s).length();
    int main_numb_part[10];

    while ( (*s)[i] != '\t' &&
            (*s)[i] != '.'  &&
            i < s_length       )
    {
        main_numb_part[i - str_position] = (*s)[i] - '0';
        i++;
    }
    i--;
    int j = 0;
    while ( i - str_position + 1 )
    {
        (*numb) += main_numb_part[j] * pow( 10, i - str_position );
        j++;
        i--;
    }
    i = str_position + j + 1;
    if ( (*s)[i - 1] == '.' )
    {
        j = -1;
        while ( (*s)[i] != '\t' &&
                (*s)[i] != '\n' &&
                i < s_length       )
        {
            (*numb) += int( (*s)[i] - '0' ) * pow( 10, j );
            j--;
            i++;
        }
        i++;
    }
    if ( minus_flag )
        (*numb) *= (-1);

    return i;
}

#define antihairpin_dG_simple_call "\
    #/bin/bash \n\
    cd ../antihairpin_dG_simple \n\
    ./antihairpin_dG_simple \n\
"

#define aff_to_group_reducer_simple_call "\
    #/bin/bash \n\
    cd ../aff_to_group_reducer_simple \n\
    ./aff_to_group_reducer_simple \n\
"

char complement_ncltd (char ncltd, int dna_flag)
{
    switch(ncltd)
    {
        case 'C':
            return 'G';
        case 'G':
            return 'C';
        case 'A':
            if (dna_flag)
                return 'T';
            return 'U';
        case 'U':
            return 'A';
        case 'T':
            return 'A';
    }
    return 'E';
}

void string_inverser (string* s)
{
    string s_copy = (*s);
    int l = (*s).length();
    for (int i = 0; i < l; i++ )
    {
        (*s)[i] = s_copy[l-1-i];
    }
}

int c_seq_maker (string* seq, string* c_seq, int dna_flag)
{
    int l = (*seq).length();
    for (int i = 0; i < l; i++ )
    {
        switch((*seq)[i])
        {
            case 'C':
                (*c_seq).push_back('G');
                break;
            case 'G':
                (*c_seq).push_back('C');
                break;
            case 'A':
                if (dna_flag)
                     (*c_seq).push_back('T');
                else (*c_seq).push_back('U');
                break;
            case 'U':
                (*c_seq).push_back('A');
                break;
            case 'T':
                (*c_seq).push_back('A');
                break;
        }
    }
    string_inverser(c_seq);
    return 0;
}

char random_ncltd (int dna_flag, int rnd_seed)
{
    srand (rnd_seed);

    switch(rand() % 4)
    {
        case 0:
            return 'A';
        case 1:
            if (dna_flag)
                return 'T';
            return 'U';
        case 2:
            return 'G';
        case 3:
            return 'C';
    }
}

void olig_generator (int olig_length,
                     string* olig_seq,
                     int dna_flag,
                     int rndm_modifier = 0)
{
    for (int i = 0; i < olig_length; i++)

        (*olig_seq).push_back( random_ncltd(dna_flag, time(NULL) + i + rndm_modifier) );
}

void input_data_reader (int* dna_flag,
                        int* oligs_nmb,
                        int* olig_length,
                        float* target_dG,
                        float* target_dG_accuracy,
                        float* limit_aff_to_each_olig_from_group,
                        string* oligs_group)
{
    string temp_str;
    float temp_fl;

    ifstream read;
    read.open(input_file);

    getline(read, temp_str);
    decimal_numb_reader(&temp_str, (int)temp_str.find(' ') + 1, &temp_fl);
    *dna_flag = (int)temp_fl;

    getline(read, temp_str);
    decimal_numb_reader(&temp_str, (int)temp_str.find(' ') + 1, &temp_fl);
    *olig_length = (int)temp_fl;

    getline(read, temp_str);
    decimal_numb_reader(&temp_str, (int)temp_str.find(' ') + 1, target_dG);

    getline(read, temp_str);
    decimal_numb_reader(&temp_str, (int)temp_str.find(' ') + 1, target_dG_accuracy);

    getline(read, temp_str);
    decimal_numb_reader(&temp_str, (int)temp_str.find(' ') + 1, &temp_fl);
    *oligs_nmb = (int)temp_fl;

    getline(read, temp_str);
    decimal_numb_reader(&temp_str, (int)temp_str.find(' ') + 1, limit_aff_to_each_olig_from_group);

    for (int i = 0; i < (*oligs_nmb); i++)
    {
        getline( read, oligs_group[i] );
        oligs_group[i].erase(oligs_group[i].begin(),
                             oligs_group[i].begin() + oligs_group[i].find(' ') + 1);
    }
    read.close();
}

int  antihairpin_maker (string* input_seq,
                        float target_dG,
                        float target_dG_accuracy,
                        int dna_flag)
{
    ofstream write;
    write.open(input_antihairpin_dG_simple);
    write << (*input_seq) << ' '
         << target_dG << ' '
         << target_dG_accuracy << ' '
         << dna_flag;
    write.close();

    system(antihairpin_dG_simple_call);

    ifstream read;
    read.open(output_antihairpin_dG_simple);
    string temp_str;
    getline(read, temp_str);
    getline(read, temp_str);
    read.close();

    if (temp_str[temp_str.length() - 1] == '+')
    {
        (*input_seq).clear();
        for (int i = 0; temp_str[i] != '\t'; i++)
            (*input_seq).push_back(temp_str[i]);
        return 1;
    }
    return 0;
}

int aff_to_group_reducer_maker (int     dna_flag,
                                string* olig_seq,
                                int     oligs_nmb,
                                float   limit_aff_to_each_olig_from_group,
                                string* oligs_group,
                                float   limit_olig_dG)
{
    ofstream write;
    write.open(input_aff_to_group_reducer_simple);
    write << "DNA_flag: " << dna_flag << endl
          << "input_olig: " << (*olig_seq) << endl
          << "oligs_nmb: " << oligs_nmb << endl
          << "min_aff_level_to_each_olig_from_group: " << limit_aff_to_each_olig_from_group;

    for (int i = 1; i <= oligs_nmb; i++)
        write << endl << i << ") " <<  oligs_group[i-1];

    write.close();

    system(aff_to_group_reducer_simple_call);

    ifstream read;
    read.open(output_aff_to_group_reducer_simple);

    getline(read, *olig_seq);

    string temp_str;
    float olig_dG;
    getline(read, temp_str);
    decimal_numb_reader(&temp_str, (int)temp_str.find('=') + 2, &olig_dG);

    getline(read, temp_str);

    for (int i = 0; i <= oligs_nmb; i++)
    {
        getline(read, temp_str);
        if (temp_str[temp_str.length() - 1] == '-')
            return -1;
    }
    read.close();

    if (olig_dG < limit_olig_dG)
        return -2;

    return 1;
}

int main()
{
    int dna_flag,
        oligs_nmb,
        olig_length;

    float target_dG,
          target_dG_accuracy,
          limit_aff_to_each_olig_from_group;

    string oligs_group[20];

    input_data_reader (&dna_flag,
                       &oligs_nmb,
                       &olig_length,
                       &target_dG,
                       &target_dG_accuracy,
                       &limit_aff_to_each_olig_from_group,
                       oligs_group);

    string olig_seq;
    int break_flag;
    ofstream write;
    write.open(output_file);

    for (int i = 0; i < 100; i++)
    {
        olig_generator(olig_length, &olig_seq, dna_flag, i*1000);
        break_flag = 0;
        for (int j = 0; j < 10; j++)
        {
            if ( antihairpin_maker (&olig_seq,
                                    target_dG,
                                    target_dG_accuracy,
                                    dna_flag)          == 0 )
                break;

            switch( aff_to_group_reducer_maker (dna_flag,
                                                &olig_seq,
                                                oligs_nmb,
                                                limit_aff_to_each_olig_from_group,
                                                oligs_group,
                                                target_dG - target_dG_accuracy)   )
            {
                case 1:
                    write << olig_seq;
                    return 0;
                case -1:
                    break_flag = 1;
            }
            if (break_flag)
                break;
        }
        olig_seq.clear();
    }
    write << "-";
    write.close();
    return 0;
}
