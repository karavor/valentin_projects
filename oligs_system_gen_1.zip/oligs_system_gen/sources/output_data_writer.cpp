#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <iomanip>
#include "my_structs.h"

using namespace std;

template<typename _DT_>
void write_vect_as_string (vector<_DT_>* vect,
                           ofstream* write,
                           char sep = '%'    )
{
    bool sep_flag = 0;

    if (sep != '%')
        sep_flag = 1;

    for (int i = 0; i < (*vect).size(); i++)
    {
        (*write) << (*vect)[i];

        if (sep_flag)
            (*write) << sep;
    }
}

void string_inverser (string* s);

void domain_writer(ofstream* write,
                   olig_domain* dom,
                   bool iverse_fl)
{
    string s = "_";

    if (iverse_fl)
        s.push_back('!');

    (*write) << s << (*dom).name;

    string seq;

    if( (*dom).nucl_seq.length() != 0 )
    {
        seq = (*dom).nucl_seq;

        if (iverse_fl)
        {
            string_inverser( &seq );
        }
        (*write) << '(' << seq << ')';
    }

    else
    {
        if ( (*dom).length != 0 )

            (*write) << '(' << (*dom).length << ')';
    }
}

void domain_base_writer (ofstream* write,
                         olig_domain* neutral_domain,
                         vector<domain_pair>* domain_base)
{
    (*write) << endl << "neutral_domain:" << endl << endl;

    domain_writer(write, neutral_domain, 0);

    (*write) << endl << endl << "domain_base:" << endl << endl;

    for (int i = 0; i < (*domain_base).size(); i++)
    {
        domain_writer(write, &( (*domain_base)[i].first ), 0 );
        domain_writer(write, &( (*domain_base)[i].second ), 0 );
        (*write) << endl;
    }
}

void oligs_writer (ofstream* write,
                   vector< vector< olig >* >* oligs_pntrs)
{
    (*write) << endl << "oligs:" << endl << endl;

    domain_ref current_domain_ref;

    for (int i = 0; i < (*oligs_pntrs).size(); i++)
    {
        for (int j = 0; j < ( *( (*oligs_pntrs)[i] ) ).size(); j++)
        {
            for (int k = 0; k < ( ( *( (*oligs_pntrs)[i] ) )[j] ).dom_seq.size(); k++)
            {
                current_domain_ref = ( ( *( (*oligs_pntrs)[i] ) )[j] ).dom_seq[k];

                domain_writer( write,
                               current_domain_ref.olig_dom,
                               current_domain_ref.iverse_flag  );
            }
            (*write) << endl;
        }
        (*write) << endl;
    }
}

void result_data_writer ( olig_domain* neutral_domain,
                          vector<domain_pair>* domain_base,
                          input_prmtrs* inp_prmtrs,
                          char     sep,
                          vector< vector< olig >* >* oligs_pntrs)
{
    const char* AAGS_result_file = "../output/AAGS_result";

    ofstream write( AAGS_result_file );
    write << setprecision(3);

    write << "dna_flag:"                 << sep << (*inp_prmtrs).dna_flag << endl
          << "max_iter_nmb_for_dmn_bld:" << sep << (*inp_prmtrs).max_iter_nmb_for_dmn_bld << endl
          << "crit_param_over_mult:"     << sep << (*inp_prmtrs).crit_param_over_mult << endl
          << "hairpin_crit_dG:"          << sep << (*inp_prmtrs).hairpin_crit_dG << endl
          << "hairpin_length:"           << sep << (*inp_prmtrs).hairpin_length << endl
          << "cmplx_crit_dG:"            << sep << (*inp_prmtrs).cmplx_crit_dG << endl
          << "GC_percentage:"            << sep << (*inp_prmtrs).GC_percentage << endl;

    domain_base_writer (&write,
                        neutral_domain,
                        domain_base);

    oligs_writer (&write, oligs_pntrs);

    write.close();
}
