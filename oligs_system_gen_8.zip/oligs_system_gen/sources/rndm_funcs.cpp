#include <string>
#include <iostream>
#include <cstdlib>

using namespace std;

char ncltd_nmb_to_ncltd_convert (bool dna_flag,
                                 int ncltd_nmb,
                                 int GC_percentage)
{
    if ( ncltd_nmb     < 0 || ncltd_nmb     > 100 ||
         GC_percentage < 0 || GC_percentage > 100   )
    {
        cout << "ncltd_nmb_to_ncltd_convert: error" <<
                " - ncltd_nmb should be from 1 to 100" << endl;
        return 0;
    }
    if (ncltd_nmb <= GC_percentage / 2 )
        return 'C';

    if (ncltd_nmb <= GC_percentage)
        return 'G';

    if (ncltd_nmb <= GC_percentage + (100 - GC_percentage) / 2 )
        return 'A';

    if (dna_flag)
        return 'T';

    return 'U';
}

int rndm_int_generator (int max_int,
                        unsigned long int rndm_modifier)
{
    unsigned long int rndm_seed = (unsigned long int)time(NULL);

    srand ( rndm_seed + rndm_modifier );

    return ( rand() % max_int );
}

void rndm_olig_gen (bool dna_flag,
                    int olig_length,
                    int GC_percentage,
                    string* olig_str,
                    unsigned long int* rndm_modifier)
{
    (*olig_str).clear();

    for (int i = 0; i < olig_length; i++)
    {
        (*rndm_modifier)++;
        (*olig_str).push_back
        (
         ncltd_nmb_to_ncltd_convert (dna_flag,
                                     rndm_int_generator (100, (*rndm_modifier) ),
                                     GC_percentage                               )
        );
    }
}

