#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>
#include "my_structs.h"

using namespace std;

struct A_n_k_elmnt_struct
{
    vector<unsigned short int> elmnt;
    float max_pttrn_cmplx_dG_score;
    vector<unsigned short int> max_pttrn_cmplx_nmbs;
};

unsigned long int int_pow (unsigned short int n, unsigned short int power);

bool current_cmplx_dG_score_test (float  current_cmplx_dG_score,
                                  float  crit_score,
                                  float* max_cmplx_dG_score,
                                  int max_pttrn_cmplx_nmb_1,
                                  int max_pttrn_cmplx_nmb_2,
                                  vector<unsigned short int>* max_pttrn_cmplx_nmbs)
{
    if ( current_cmplx_dG_score > (*max_cmplx_dG_score) )
    {
        (*max_cmplx_dG_score) = current_cmplx_dG_score;
    }

    if ( current_cmplx_dG_score > crit_score )
    {
        (*max_pttrn_cmplx_nmbs)[0] = max_pttrn_cmplx_nmb_1;
        (*max_pttrn_cmplx_nmbs)[1] = max_pttrn_cmplx_nmb_2;
        return 1;
    }
    return 0;
}

bool A_n_k_elmnt_test ( A_n_k_elmnt_struct* A_n_k_elmnt,
                        float crit_score,
                        vector< vector<two_pttrn_gluing> >* gluing_matrix)
{
    (*A_n_k_elmnt).max_pttrn_cmplx_dG_score = 0;
    (*A_n_k_elmnt).max_pttrn_cmplx_nmbs.clear();
    (*A_n_k_elmnt).max_pttrn_cmplx_nmbs.push_back(0);
    (*A_n_k_elmnt).max_pttrn_cmplx_nmbs.push_back(0);

    if ( (*A_n_k_elmnt).elmnt.size() == 1 )
    {
        if ( current_cmplx_dG_score_test ( (*gluing_matrix)[ (*A_n_k_elmnt).elmnt[0] ]
                                                           [ (*A_n_k_elmnt).elmnt[0] ].cmplx_dG_score,
                                           crit_score,
                                           &((*A_n_k_elmnt).max_pttrn_cmplx_dG_score),
                                           (*A_n_k_elmnt).elmnt[0],
                                           (*A_n_k_elmnt).elmnt[0],
                                           &((*A_n_k_elmnt).max_pttrn_cmplx_nmbs)     ) )
        {
            return 0;
        }
        return 1;
    }

    int last_in_A_n_k_elmnt_pttrn_nmb
        =
        (*A_n_k_elmnt).elmnt[ (*A_n_k_elmnt).elmnt.size() - 1 ];

    int last_to_last_in_A_n_k_elmnt_pttrn_nmb
        =
        (*A_n_k_elmnt).elmnt[ (*A_n_k_elmnt).elmnt.size() - 2 ];

    two_pttrn_gluing current_gluing_matrix_elmnt
    =
    (*gluing_matrix)[last_to_last_in_A_n_k_elmnt_pttrn_nmb]
                    [    last_in_A_n_k_elmnt_pttrn_nmb    ];

    vector<int> new_appeared_pttrns_nmbs = current_gluing_matrix_elmnt.appeared_pttrns_nmbs;

    new_appeared_pttrns_nmbs.push_back(last_in_A_n_k_elmnt_pttrn_nmb);

    float current_cmplx_dG_score;

    for (int i = 0; i < new_appeared_pttrns_nmbs.size(); i++)
    {
        current_cmplx_dG_score
        =
        (*gluing_matrix)[ new_appeared_pttrns_nmbs[i] ]
                        [ new_appeared_pttrns_nmbs[i] ].cmplx_dG_score;

        if ( current_cmplx_dG_score_test (current_cmplx_dG_score,
                                          crit_score,
                                          &((*A_n_k_elmnt).max_pttrn_cmplx_dG_score),
                                          new_appeared_pttrns_nmbs[i],
                                          new_appeared_pttrns_nmbs[i],
                                          &((*A_n_k_elmnt).max_pttrn_cmplx_nmbs)     ) )
        {
            return 0;
        }
    }

    int k;

    for (int i = 0; i < new_appeared_pttrns_nmbs.size(); i++)
    {
        for (int j = 0; j < (*A_n_k_elmnt).elmnt.size() - 1; j++)
        {
            current_cmplx_dG_score
            =
            (*gluing_matrix)[ new_appeared_pttrns_nmbs[i] ]
                            [   (*A_n_k_elmnt).elmnt[j]   ].cmplx_dG_score;

            if ( current_cmplx_dG_score_test (current_cmplx_dG_score,
                                              crit_score,
                                              &((*A_n_k_elmnt).max_pttrn_cmplx_dG_score),
                                              new_appeared_pttrns_nmbs[i],
                                              (*A_n_k_elmnt).elmnt[j],
                                              &((*A_n_k_elmnt).max_pttrn_cmplx_nmbs)     ) )
            {
                return 0;
            }

            if (j == (*A_n_k_elmnt).elmnt.size() - 2)
            {
                if (i != new_appeared_pttrns_nmbs.size() - 1)

                    k = i + 1;
                else
                    k = 0;
            }
            else
                k = 0;

            for (k; k < new_appeared_pttrns_nmbs.size() - 1; k++)
            {
                current_cmplx_dG_score
                =
                (*gluing_matrix)[ new_appeared_pttrns_nmbs[i] ]
                                [   (*gluing_matrix)[ (*A_n_k_elmnt).elmnt[  j  ] ]
                                                    [ (*A_n_k_elmnt).elmnt[j + 1] ].appeared_pttrns_nmbs[k] ].cmplx_dG_score;

                if ( current_cmplx_dG_score_test (current_cmplx_dG_score,
                                                  crit_score,
                                                  &((*A_n_k_elmnt).max_pttrn_cmplx_dG_score),
                                                  new_appeared_pttrns_nmbs[i],
                                                  (*gluing_matrix)[ (*A_n_k_elmnt).elmnt[  j  ] ]
                                                                  [ (*A_n_k_elmnt).elmnt[j + 1] ].appeared_pttrns_nmbs[k],
                                                  &((*A_n_k_elmnt).max_pttrn_cmplx_nmbs)                                  )  )
                {
                    return 0;
                }
            }
        }
    }
    return 1;
}

short int nmb_in_interval_test (unsigned long int nmb,
                                unsigned long int left_interval_border,
                                unsigned long int right_interval_border)
{
    if (left_interval_border > right_interval_border)
    {
        cout << "interval test error: left border > right border" << endl;
        return 2;
    }

    if (nmb < left_interval_border)
        return -1;

    if (nmb > right_interval_border)
        return 1;

    return 0;
}

bool forbidden_A_n_k_elmnt_nmb_test( unsigned short int pttrn_base_size,
                                     unsigned short int current_iter_nmb,
                                     unsigned long int* current_A_n_k_elmnt_nmb,
                                     vector< vector<unsigned long int> >* forbidden_A_n_k_elmnts_nmbs_stat )
{
    for ( unsigned short int i = 0;
          i < (*forbidden_A_n_k_elmnts_nmbs_stat).size();
          i++ )
    {
        if ( (i + 1) == current_iter_nmb )
            break;

        for (unsigned long int j = 0;
             j < (*forbidden_A_n_k_elmnts_nmbs_stat)[i].size();
             j++)
        {
            switch( nmb_in_interval_test ( (*current_A_n_k_elmnt_nmb),

                                           (*forbidden_A_n_k_elmnts_nmbs_stat)[i][j]
                                           *
                                           int_pow( pttrn_base_size,
                                                    current_iter_nmb - (i + 1) ),

                                           ( (*forbidden_A_n_k_elmnts_nmbs_stat)[i][j] + 1 )
                                           *
                                           int_pow( pttrn_base_size,
                                                    current_iter_nmb - (i + 1) )            ) )
            {
                case 0:
                    (*current_A_n_k_elmnt_nmb) = ((*forbidden_A_n_k_elmnts_nmbs_stat)[i][j] + 1)
                                                 *
                                                 int_pow( pttrn_base_size,
                                                          current_iter_nmb - (i + 1) );
                    return 0;

                case -1:
                    j = (*forbidden_A_n_k_elmnts_nmbs_stat)[i].size() + 1;
                    break;
            }
        }
    }
    return 1;
}

void olig_from_nmbs_to_string_convert (string* str_olig,
                                       vector<unsigned short int>* nmbs_olig,
                                       vector<string>* pttrn_base);

void A_n_k_maker_stat_writer ( ofstream* write,
                               vector<unsigned short int>* nmbs_olig,
                               float max_pttrn_cmplx_dG_score,
                               vector<string>* pttrn_base)
{
    string olig;

    olig_from_nmbs_to_string_convert( &olig,
                                      nmbs_olig,
                                      pttrn_base  );

    (*write) << olig << '\t' << max_pttrn_cmplx_dG_score << endl;
}

/*
void A_n_k_maker_stat_writer ( ofstream* write,
                               int iter_nmb,
                               vector< A_n_k_elmnt >* A_n_k,
                               vector< vector<unsigned short int> >*
                                     forbidden_A_n_k_elmnts_nmbs_stat)
{
    (*write) << endl << iter_nmb << endl << endl;

    char sep = '\t';

    for (int i = 0; i < (*A_n_k).size(); i++)
    {
        (*write) << sep << (*A_n_k)[i].nmb << sep;

        write_vect_as_string <unsigned short int> ( &((*A_n_k)[i].elmnt),
                                                     write                );
        (*write) << endl;
    }
    (*write) << endl;

    for (int j = 0; j < (*forbidden_A_n_k_elmnts_nmbs_stat)[iter_nmb].size(); j++)
    {
        (*write) << sep << (*forbidden_A_n_k_elmnts_nmbs_stat)[iter_nmb][j] << endl;
    }
}
*/
void ten_to_n_nmb_sys (unsigned long int ten_nmb,
                       unsigned short int n,
                       vector<unsigned short int>* n_nmb,
                       unsigned short int n_nmb_final_size )
{
    unsigned short int excess;

    (*n_nmb).clear();

    while (ten_nmb > n - 1)
    {
        excess = ten_nmb % n;
        (*n_nmb).insert( (*n_nmb).begin(), excess );
        ten_nmb /= n;
    }
    (*n_nmb).insert( (*n_nmb).begin(), ten_nmb );

    while( (*n_nmb).size() < n_nmb_final_size )
    {
        (*n_nmb).insert( (*n_nmb).begin(), 0 );
    }
}

unsigned long int n_nmb_to_ten_sys (unsigned short int n,
                                    vector<unsigned short int>* n_nmb )
{
    unsigned long int result = 0;

    for (int i = 0; i < (*n_nmb).size(); i++)
    {
        result += (*n_nmb)[i] * int_pow (n, (*n_nmb).size() - i - 1);
    }
    return result;
}

unsigned long int ul_int_numb_reader (string* s)
{
    unsigned long int result = 0;
    int ten_pow = 0;

    for (int i = (*s).length() - 1; i >= 0 ; i--)
    {
        result += ( (int)(*s)[i] - 48 ) * int_pow (10, ten_pow);
        ten_pow++;
    }
    return result;
}

bool int_in_vect_finder (unsigned short int nmb,
                         vector<unsigned short int>* int_vect)
{
    for (int i = 0; i < (*int_vect).size(); i++)
    {
        if ( (*int_vect)[i] == nmb )
            return 1;
    }
    return 0;
}

bool rndm_int_without_repeat_generator (vector<unsigned short int>* int_vect,
                                        unsigned short int int_nmb,
                                        unsigned short int min_int,
                                        unsigned short int max_int,
                                        unsigned long int rndm_modifier)
{
    if ( int_nmb > (max_int - min_int + 1) )
    {
        cout << endl << "Error in function rndm_int_without_repeat_generator";
        return 1;
    }

    (*int_vect).clear();

    unsigned short int rndm_int;
    unsigned short int j = 1;

    unsigned long int rndm_seed = (unsigned long int)time(NULL) + rndm_modifier;

    for (unsigned short int i = 1; i <= int_nmb; i++)
    {
        do
        {
            srand ( rndm_seed*i*j );

            rndm_int = rand() % max_int;
            j++;
        }
        while ( int_in_vect_finder(rndm_int, int_vect) );

        (*int_vect).push_back( rndm_int );
    }
    return 0;
}

bool forb_elmnts_nmbs_reader ( vector< vector<unsigned long int> >* forbidden_A_n_k_elmnts_nmbs_stat )
{
    ifstream forb_elmnts_nmbs_read ("../input/forb_elmnts_nmbs");
    string read_string;
    string nmb;
    vector<unsigned long int> add_vect;
    char sep = ' ';

    while ( !forb_elmnts_nmbs_read.eof() )
    {
        getline(forb_elmnts_nmbs_read, read_string);
        if ( read_string.size() )
        {
            for (unsigned int i = 0; i < read_string.size(); i++)
            {
                while ( read_string[i] != sep )
                {
                    nmb.push_back(read_string[i]);
                    i++;
                }
                add_vect.push_back( ul_int_numb_reader(&nmb) );
                nmb.clear();
            }
            (*forbidden_A_n_k_elmnts_nmbs_stat).push_back(add_vect);
            add_vect.clear();
        }
    }
    forb_elmnts_nmbs_read.close();
    return 0;
}

bool rndm_A_n_k_maker ( vector<string>* pttrn_base,
                        unsigned long int oligs_nmb,
                        unsigned short int k,
                        float crit_score,
                        vector< vector<two_pttrn_gluing> >* gluing_matrix )
{
    A_n_k_elmnt_struct current_A_n_k_elmnt;
    A_n_k_elmnt_struct part_current_A_n_k_elmnt;
    ofstream write ("../output/A_n_k_maker_stat");

    for (unsigned long int i = 0; i < oligs_nmb; i++)
    {
//if (iter_nmb == 2 && current_A_n_k_elmnt_nmb == 256) cout << endl << "Q" << endl;

        rndm_int_without_repeat_generator (&(current_A_n_k_elmnt.elmnt),
                                           k,
                                           0,
                                           (*pttrn_base).size() - 1,
                                           i);

//if (iter_nmb == 2 && current_A_n_k_elmnt_nmb == 256) cout << endl << "W" << endl;
        for (int j = 0; j < k; j++)
        {
            part_current_A_n_k_elmnt.elmnt.push_back( current_A_n_k_elmnt.elmnt[j] );

            if ( A_n_k_elmnt_test( &part_current_A_n_k_elmnt,
                                    crit_score,
                                    gluing_matrix        ) )
            {
    //if (iter_nmb == 2 && current_A_n_k_elmnt_nmb == 256) cout << endl << "R" << endl;
                if ( j == (k - 1) )
                    A_n_k_maker_stat_writer ( &write,
                                            &(part_current_A_n_k_elmnt.elmnt),
                                            part_current_A_n_k_elmnt.max_pttrn_cmplx_dG_score,
                                            pttrn_base );
    //if (iter_nmb == 2 && current_A_n_k_elmnt_nmb == 256) cout << endl << "T" << endl;
            }
            else
                break;

            part_current_A_n_k_elmnt.max_pttrn_cmplx_nmbs.clear();
        }

        part_current_A_n_k_elmnt.max_pttrn_cmplx_nmbs.clear();
        part_current_A_n_k_elmnt.elmnt.clear();
        cout << part_current_A_n_k_elmnt.max_pttrn_cmplx_dG_score << endl;
    }
    write.close();
    return 0;
}

bool modified_A_n_k_maker ( vector<string>* pttrn_base,
                            unsigned short int n,
                            unsigned short int k,
                            float crit_score,
                            vector< vector<two_pttrn_gluing> >* gluing_matrix )
{
/*
    vector<unsigned short int> vect;
    string olig;
    unsigned long int current_elmnt_nmb = 11534592;
    char sep = ' ';

    ten_to_n_nmb_sys (current_elmnt_nmb,
                      (*gluing_matrix).size(),
                      &vect,
                      vect.size()             );

    cout << vect[0] << sep << vect[1] << sep << vect[2] << endl;

    olig_from_nmbs_to_string_convert( &olig,
                                      &vect,
                                      pttrn_base  );

    cout << current_elmnt_nmb << sep << olig << endl;

    return 0;
*/
    if ( n < k )
        return 1;

    vector< vector<unsigned long int> > forbidden_A_n_k_elmnts_nmbs_stat;

    forb_elmnts_nmbs_reader(&forbidden_A_n_k_elmnts_nmbs_stat);

    ofstream write ("../output/A_n_k_maker_stat");
    ofstream forb_elmnts_nmbs_write ("../input/forb_elmnts_nmbs_new");
    char sep = ' ';

    //ofstream dbg_write_0_1 ("../output/A_n_k_maker_stat_dbg_0_1");
    //ofstream dbg_write_0_0 ("../output/A_n_k_maker_stat_dbg_0_0");
    //ofstream dbg_write_1_0 ("../output/A_n_k_maker_stat_dbg_1_0");
/*
    A_n_k_maker_stat_writer(&write,
                            0,
                            A_n_k,
                            &forbidden_A_n_k_elmnts_nmbs_stat);
*/

    A_n_k_elmnt_struct current_A_n_k_elmnt;
    vector<unsigned long int> init_vect;

    for (int iter_nmb = forbidden_A_n_k_elmnts_nmbs_stat.size() + 1; iter_nmb <= k; iter_nmb++)
    {
        forbidden_A_n_k_elmnts_nmbs_stat.push_back(init_vect);

        for (unsigned long int current_A_n_k_elmnt_nmb = 0;
             current_A_n_k_elmnt_nmb < int_pow( (*gluing_matrix).size(), iter_nmb );
             current_A_n_k_elmnt_nmb++)
        {
//if (iter_nmb == 2 && current_A_n_k_elmnt_nmb == 256) cout << endl << "Q" << endl;

            ten_to_n_nmb_sys (current_A_n_k_elmnt_nmb,
                              (*gluing_matrix).size(),
                              &(current_A_n_k_elmnt.elmnt),
                              iter_nmb                     );
//if (iter_nmb == 2 && current_A_n_k_elmnt_nmb == 256) cout << endl << "W" << endl;
            if ( !forbidden_A_n_k_elmnt_nmb_test( (*gluing_matrix).size(),
                                                  iter_nmb,
                                                  &current_A_n_k_elmnt_nmb,
                                                  &forbidden_A_n_k_elmnts_nmbs_stat ) )
            {
                //cout << current_A_n_k_elmnt_nmb << endl;
                continue;
            }
/*
if (iter_nmb == 2 && current_A_n_k_elmnt_nmb == 256) cout << endl << "E" << endl;
if (iter_nmb == 2 && current_A_n_k_elmnt_nmb == 256)
for (int p = 0; p < current_A_n_k_elmnt.elmnt.size(); p++)
    cout << current_A_n_k_elmnt.elmnt[p] << ' ';
cout << endl;
*/
            if ( A_n_k_elmnt_test( &current_A_n_k_elmnt,
                                   crit_score,
                                   gluing_matrix        ) )
            {
//if (iter_nmb == 2 && current_A_n_k_elmnt_nmb == 256) cout << endl << "R" << endl;
                    write << current_A_n_k_elmnt_nmb << '\t';
                    A_n_k_maker_stat_writer ( &write,
                                              &(current_A_n_k_elmnt.elmnt),
                                              current_A_n_k_elmnt.max_pttrn_cmplx_dG_score,
                                              pttrn_base );
//if (iter_nmb == 2 && current_A_n_k_elmnt_nmb == 256) cout << endl << "T" << endl;
            }
            else
            {
//if (iter_nmb == 2 && current_A_n_k_elmnt_nmb == 256) cout << endl << "Y" << endl;

                forbidden_A_n_k_elmnts_nmbs_stat
                [forbidden_A_n_k_elmnts_nmbs_stat.size() - 1].
                push_back( current_A_n_k_elmnt_nmb );

                forb_elmnts_nmbs_write << current_A_n_k_elmnt_nmb << sep;
/*
                dbg_write_1_0 << iter_nmb << '\t' << i << '\t' << j << endl
                              << current_A_n_k_elmnt.max_pttrn_cmplx_nmbs[0] << '\t'
                                       << current_A_n_k_elmnt.max_pttrn_cmplx_nmbs[1] << endl;

                         A_n_k_maker_stat_writer ( &dbg_write_1_0,
                                                   &(current_A_n_k_elmnt.elmnt),
                                                   current_A_n_k_elmnt.max_pttrn_cmplx_dG_score,
                                                   pttrn_base);
*/
            }
            cout << current_A_n_k_elmnt.max_pttrn_cmplx_dG_score << endl;
        }
        forb_elmnts_nmbs_write << endl;
        write << endl << endl;
    }
    write.close();
    forb_elmnts_nmbs_write.close();
    return 0;
}
