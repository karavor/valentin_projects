#include <iostream>
#include <string>

using namespace std;

char user_answer_reader( string* answer_variants )
{
    char user_answer;

    while (1)
    {
        cin >> user_answer;

        for (int i = 0; i < (*answer_variants).length(); i++)
        {
            if ( user_answer == (*answer_variants)[i] )
                return (*answer_variants)[i];
        }

        cout << "Incorrect answer, you should write" << endl
             << (*answer_variants)[0];

        for (int i = 1; i < (*answer_variants).length(); i++)
        {
            cout << " or " << (*answer_variants)[i];
        }

        cout << endl << "Try again" << endl;
    }
}

void open_input_file ( ifstream* read_file,
                       char logic_type,
                       char fixed_olig_type,
                       char staple_direction )
{
    switch ( logic_type )
    {
        case 'Y':
            if ( fixed_olig_type == 'I' )
                (*read_file).open( "../interface_files/yes_inp_fix" );
            else
                (*read_file).open( "../interface_files/yes_shield_fix" );
            break;

        case 'N':
            if ( fixed_olig_type == 'I' )
                (*read_file).open( "../interface_files/not_inp_fix" );
            else
                (*read_file).open( "../interface_files/not_shield_fix" );
            break;

        case 'A':
            if ( fixed_olig_type == 'I' )
            {
                if ( staple_direction == '1' )
                    (*read_file).open( "../interface_files/and_inp_fix_dir_1" );
                else
                    (*read_file).open( "../interface_files/and_inp_fix_dir_2" );
            }
            else
            {
                if ( staple_direction == '1' )
                    (*read_file).open( "../interface_files/and_shield_fix_dir_1" );
                else
                    (*read_file).open( "../interface_files/and_shield_fix_dir_2" );
            }

            break;
    }
}

void inp_str_maker (string* inp_str,
                    string* dom_1,
                    string* dom_2)
{
    string s1, s2, s3;

    for ( int i = 0; i < (*inp_str).find( '(' ) + 1; i++ )
        s1.push_back( (*inp_str)[i] );

    (*inp_str).erase( (*inp_str).begin(),
                      (*inp_str).begin() + (*inp_str).find( '(' ) + 1 );

    for ( int i = (*inp_str).find( '(' ) + 1; i < (*inp_str).length(); i++ )
        s2.push_back( (*inp_str)[i] );

    (*inp_str).erase( (*inp_str).begin() + (*inp_str).find( '(' ) + 1,
                      (*inp_str).end() );

    (*inp_str) = s1 + (*dom_1) + (*inp_str) + (*dom_2) + s2;
}

bool olig_string_reader (string* olig_str)
{
    bool break_flag;

    while (1)
    {
        cin >> (*olig_str);

        break_flag = 0;

        for (int i = 0; i < (*olig_str).length(); i++)
        {
            if ( (*olig_str)[i] != 'A'
                 &&
                 (*olig_str)[i] != 'T'
                 &&
                 (*olig_str)[i] != 'G'
                 &&
                 (*olig_str)[i] != 'C' )
            {
                break_flag = 1;
                break;
            }
        }
        if ( break_flag )
        {
            cout << "Incorrect nucleotide sequence, it should consist of A/T/G/C only" << endl
                 << "Try again" << endl;
        }
        else
            return 0;
    }
}

void yes_not_input_file_maker( ifstream* read_file,
                               ofstream* input_file )
{
    string read_str;
    string first_domain;
    string second_domain;
    int string_counter = 0;

    do
    {
        getline( (*read_file), read_str);
        string_counter++;

        if ( string_counter == 16 )
        {
            cout << "Enter the first (1 from 2) domain of fixed olig: " ;
            olig_string_reader (&first_domain);

            cout << "Enter the second (2 from 2) domain of fixed olig: " ;
            olig_string_reader (&second_domain);

            inp_str_maker( &read_str, &first_domain, &second_domain );
        }
        (*input_file) << read_str << endl;
    }
    while ( !(*read_file).eof() )
}

void and_input_file_maker( ifstream* read_file,
                           ofstream* input_file )
{

}

bool interface()
{
    cout << "Select the program mode: interactive (I) or default (D)" << endl;

    string answer_variants = "ID";

    if ( user_answer_reader( &answer_variants ) == 'D' )
    {
        return 0;
    }

    cout << "Select the logic type: YES (Y) / NOT (N) / AND (A)" << endl;

    answer_variants = "YNA";

    char logic_type = user_answer_reader( &answer_variants );

    cout << "Select the fixed olig: input (I) / shield (S)" << endl;

    answer_variants = "IS";

    char fixed_olig_type = user_answer_reader( &answer_variants );

    char staple_direction;

    if ( logic_type == 'A' )
    {
        cout << "Select staple direction: type_1 (1) / type_2 (2)" << endl;

        answer_variants = "12";

        staple_direction = user_answer_reader( &answer_variants );
    }

    ifstream read_file;

    open_input_file ( &read_file,
                      logic_type,
                      fixed_olig_type,
                      staple_direction );

    ofstream input_file ("../input/OSG_input");

    if ( logic_type == 'Y'
        ||
         logic_type == 'N')
    {
        yes_not_input_file_maker(&read_file,
                                 &input_file);
    }
    else
        and_input_file_maker(&read_file,
                             &input_file);



    return 0;
}
