#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include "my_structs.h"

using namespace std;

float decimal_numb_reader( string* s );

float string_with_prmtr_reader(ifstream* read,
                               char      sep)
{
    string read_str;
    getline( (*read), read_str);
    read_str.erase( read_str.begin(), read_str.begin() + read_str.find( sep ) + 1 );
    return decimal_numb_reader(&read_str);
}

void string_to_string_writer (string* s_from,
                              string* s_to,
                              char c_from,
                              char c_to)
{
    (*s_to).clear();

    for (size_t i  = (*s_from).find( c_from ) + 1;
                i != (*s_from).find( c_to );   i++)

        (*s_to).push_back( (*s_from)[i] );
}

void string_inverser (string* s);

bool oligs_reader (bool dna_flag,
                   ifstream* read,
                   olig_domain* neutral_domain,
                   vector< vector< olig >* >* oligs_pntrs,
                   vector<domain_pair>* domain_base    )
{
    string read_str = "|";

    olig new_olig;

    domain_ref current_dom_ref;

    domain_pair new_olig_domain;

    string sep_letters = "dubi;";

    string domain_nucl_nmb;

    for (int j = 0; j < 5; j++)
    {
        while ( (read_str[0] != sep_letters[j])
                &&
                !(*read).eof()  )
        {
            getline( (*read), read_str);

            if ( read_str[0] != '_' )
                continue;

            while ( read_str.length() )
            {
                if (j == 0)
                {
                    (*neutral_domain).name = read_str[1];

                    if ( read_str[3] >= 'A' )
                    {
                        string_to_string_writer(&read_str,
                                                &( (*neutral_domain).nucl_seq ),
                                                '(', ')');
                    }
                    else
                    {
                        string_to_string_writer(&read_str,
                                                &domain_nucl_nmb,
                                                '(', ')');

                        (*neutral_domain).length
                        =
                        (int) decimal_numb_reader(&domain_nucl_nmb);
                    }
                    break;
                }

                if (read_str[1] == '!')
                {
                    current_dom_ref.iverse_flag = 1;
                    new_olig_domain.first.name = read_str[2];
                }
                else
                {
                    current_dom_ref.iverse_flag = 0;
                    new_olig_domain.first.name = read_str[1];
                }
                if ( read_str[1] == '#')
                {
                    new_olig_domain.neutral_dom_flag = 1;
                    new_olig_domain.first.name = read_str[2];
                }

                current_dom_ref.dom_name = new_olig_domain.first.name;
                current_dom_ref.neutral_dom_length = 0;

                if (new_olig_domain.first.name == (*neutral_domain).name)
                {
                    if (read_str[2] == '(')
                    {
                        string_to_string_writer(&read_str,
                                                &domain_nucl_nmb,
                                                '(', ')');

                        current_dom_ref.neutral_dom_length
                        =
                        (int) decimal_numb_reader(&domain_nucl_nmb);

                        read_str.erase( read_str.begin(),
                                        read_str.begin() + read_str.find( ')' ) + 1);
                    } else
                    {
                        read_str.erase( read_str.begin(),
                                        read_str.begin() + 2);
                    }
                    new_olig.dom_seq.push_back(current_dom_ref);
                    continue;
                }

                new_olig.dom_seq.push_back(current_dom_ref);

                if (j == 1)
                {
                    string_to_string_writer(&read_str,
                                            &new_olig_domain.first.nucl_seq,
                                            '(', ')');

                    if (current_dom_ref.iverse_flag)
                    {
                        string_inverser(&new_olig_domain.first.nucl_seq);
                    }
                }

                if (j == 2)
                {
                    string_to_string_writer(&read_str,
                                            &domain_nucl_nmb,
                                            '(', ')');

                    new_olig_domain.first.length
                    =
                    (int) decimal_numb_reader(&domain_nucl_nmb);
                }

                if (j == 1 || j == 2)
                {
                    read_str.erase( read_str.begin(),
                                    read_str.begin() + read_str.find( ')' ) + 1);

                    if ( new_olig_domain.neutral_dom_flag == 0 )
                    {
                        new_olig_domain.second_domain_maker(dna_flag);

                        //new_olig_domain.complex_dG_calc( dna_flag );
                    }

                   (*domain_base).push_back(new_olig_domain);

                    new_olig_domain.pair_clear();
                }
                else
                {
                    read_str.erase( read_str.begin(),
                                    read_str.begin() + 2);
                }
            }
            if (j != 0)
            {
                ( *( (*oligs_pntrs)[j - 1] ) ).push_back(new_olig);

                new_olig.dom_seq.clear();
            }
        }
    }
    return 0;
}

bool domain_in_base_finder( char name,
                            olig_domain* neutral_domain,
                            vector<domain_pair>* domain_base,
                            olig_domain** finding_dom,
                            domain_pair** finding_dom_pair)
{
    if ( name == (*neutral_domain).name )
    {
        (*finding_dom) = neutral_domain;
        return 0;
    }

    for (int i = 0; i < (*domain_base).size(); i++)
    {
        if ( name == (*domain_base)[i].first.name )
        {
            (*finding_dom) = &( (*domain_base)[i].first );
            (*finding_dom_pair) = &( (*domain_base)[i] );
            return 1;
        }

        if ( (*domain_base)[i].neutral_dom_flag )
            continue;

        if ( name == (*domain_base)[i].second.name )
        {
            (*finding_dom) = &( (*domain_base)[i].second );
            (*finding_dom_pair) = &( (*domain_base)[i] );
            return 1;
        }
    }
    cout << endl << endl << "bracket or input olig domain name: " << name << endl
         << "doesn't complement to any domain name of defined or undefined oligs" << endl << endl;
    return 1;
}

bool domain_refs_maker ( vector< vector< olig >* >* oligs_pntrs,
                         olig_domain* neutral_domain,
                         vector<domain_pair>* domain_base)
{
    olig* current_olig;
    bool break_flag;
    float strongest_dG;
    float current_dG;

    for (int i = 0; i < (*oligs_pntrs).size(); i++)
    {
        for (int j = 0; j < ( *( (*oligs_pntrs)[i] ) ).size(); j++)
        {
            current_olig = &( ( *( (*oligs_pntrs)[i] ) )[j] );

            for (int k = 0; k < ( *current_olig ).dom_seq.size(); k++)
            {
                domain_in_base_finder( ( *current_olig ).dom_seq[k].dom_name,
                                       neutral_domain,
                                       domain_base,
                                       &( ( *current_olig ).dom_seq[k].olig_dom ),
                                       &( ( *current_olig ).dom_seq[k].dom_pair )  );
            }
            //( *current_olig ).strongest_dG_calc( (*neutral_domain).name );
        }
    }
    return 0;
}

bool input_data_reader (olig_domain* neutral_domain,
                        vector<domain_pair>* domain_base,
                        input_prmtrs* inp_prmtrs,
                        char          sep,
                        vector< vector< olig >* >* oligs_pntrs)
{
    const char* input_file_path = "../input/OSG_input";

    ifstream read;
    read.open(input_file_path);

    (*inp_prmtrs).dna_flag                 = (bool) string_with_prmtr_reader(&read, sep);
    (*inp_prmtrs).max_iter_nmb_for_dmn_bld = (int) string_with_prmtr_reader(&read, sep);
    (*inp_prmtrs).hairpin_crit_dG          = string_with_prmtr_reader(&read, sep);
    (*inp_prmtrs).hairpin_length           = (int) string_with_prmtr_reader(&read, sep);
    (*inp_prmtrs).cmplx_crit_dG            = string_with_prmtr_reader(&read, sep);
    (*inp_prmtrs).cmplx_length             = (int) string_with_prmtr_reader(&read, sep);
    (*inp_prmtrs).GC_percentage            = (int) string_with_prmtr_reader(&read, sep);

    oligs_reader ( (*inp_prmtrs).dna_flag,
                   &read,
                   neutral_domain,
                   oligs_pntrs,
                   domain_base);

    read.close();

    domain_refs_maker ( oligs_pntrs,
                        neutral_domain,
                        domain_base    );

    return 0;
}
