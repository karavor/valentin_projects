#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "my_structs.h"

using namespace std;

unsigned long int int_pow (unsigned long int n, unsigned short int power);

bool current_cmplx_dG_score_test (float* current_cmplx_dG_score,
                                  float* crit_score,
                                  float* max_cmplx_dG_score,
                                  int max_pttrn_cmplx_nmb_1,
                                  int max_pttrn_cmplx_nmb_2,
                                  vector<unsigned short int>* max_pttrn_cmplx_nmbs)
{
    if ( (*current_cmplx_dG_score) > (*max_cmplx_dG_score) )
    {
        (*max_cmplx_dG_score) = (*current_cmplx_dG_score);
    }

    if ( (*current_cmplx_dG_score) > (*crit_score) )
    {
        (*max_pttrn_cmplx_nmbs)[0] = max_pttrn_cmplx_nmb_1;
        (*max_pttrn_cmplx_nmbs)[1] = max_pttrn_cmplx_nmb_2;
        return 1;
    }

    return 0;
}

struct A_n_k_elmnt_struct
{
    vector<unsigned short int> elmnt;
    float max_pttrn_cmplx_dG_score;
    vector<unsigned short int> max_pttrn_cmplx_nmbs;
};

bool A_n_k_elmnt_test ( A_n_k_elmnt_struct* A_n_k_elmnt,
                        float crit_score,
                        vector< vector<two_pttrn_gluing> >* gluing_matrix )
{
    (*A_n_k_elmnt).max_pttrn_cmplx_dG_score = 0;
    (*A_n_k_elmnt).max_pttrn_cmplx_nmbs.push_back(0);
    (*A_n_k_elmnt).max_pttrn_cmplx_nmbs.push_back(0);


    int last_in_A_n_k_elmnt_pttrn_nmb
        =
        (*A_n_k_elmnt).elmnt[ (*A_n_k_elmnt).elmnt.size() - 1 ];

    int last_to_last_in_A_n_k_elmnt_pttrn_nmb
        =
        (*A_n_k_elmnt).elmnt[ (*A_n_k_elmnt).elmnt.size() - 2 ];

    two_pttrn_gluing current_gluing_matrix_elmnt
    =
    (*gluing_matrix)[last_to_last_in_A_n_k_elmnt_pttrn_nmb]
                    [    last_in_A_n_k_elmnt_pttrn_nmb    ];

    vector<int> new_appeared_pttrns_nmbs = current_gluing_matrix_elmnt.appeared_pttrns_nmbs;

    float current_cmplx_dG_score;

    for (int i = 0; i < new_appeared_pttrns_nmbs.size(); i++)
    {
        current_cmplx_dG_score
        =
        (*gluing_matrix)[ new_appeared_pttrns_nmbs[i] ]
                        [ new_appeared_pttrns_nmbs[i] ].cmplx_dG_score;

        if ( current_cmplx_dG_score_test (&current_cmplx_dG_score,
                                          &crit_score,
                                          &((*A_n_k_elmnt).max_pttrn_cmplx_dG_score),
                                          new_appeared_pttrns_nmbs[i],
                                          new_appeared_pttrns_nmbs[i],
                                          &((*A_n_k_elmnt).max_pttrn_cmplx_nmbs)     ) )
        {
            return 0;
        }
    }

    new_appeared_pttrns_nmbs.push_back(last_in_A_n_k_elmnt_pttrn_nmb);

    int k;

    for (int i = 0; i < new_appeared_pttrns_nmbs.size(); i++)
    {
        for (int j = 0; j < (*A_n_k_elmnt).elmnt.size() - 1; j++)
        {
            current_cmplx_dG_score
            =
            (*gluing_matrix)[ new_appeared_pttrns_nmbs[i] ]
                            [   (*A_n_k_elmnt).elmnt[j]   ].cmplx_dG_score;

            if ( current_cmplx_dG_score_test (&current_cmplx_dG_score,
                                              &crit_score,
                                              &((*A_n_k_elmnt).max_pttrn_cmplx_dG_score),
                                              new_appeared_pttrns_nmbs[i],
                                              (*A_n_k_elmnt).elmnt[j],
                                              &((*A_n_k_elmnt).max_pttrn_cmplx_nmbs)     ) )
            {
                return 0;
            }

            if (j == (*A_n_k_elmnt).elmnt.size() - 2)
            {
                if (i != new_appeared_pttrns_nmbs.size() - 1)

                    k = i + 1;
                else
                    k = 0;
            }
            else
                k = 0;

            for (k; k < new_appeared_pttrns_nmbs.size() - 1; k++)
            {
                current_cmplx_dG_score
                =
                (*gluing_matrix)[ new_appeared_pttrns_nmbs[i] ]
                                [   (*gluing_matrix)[ (*A_n_k_elmnt).elmnt[  j  ] ]
                                                    [ (*A_n_k_elmnt).elmnt[j + 1] ].appeared_pttrns_nmbs[k] ].cmplx_dG_score;

                if ( current_cmplx_dG_score_test (&current_cmplx_dG_score,
                                                  &crit_score,
                                                  &((*A_n_k_elmnt).max_pttrn_cmplx_dG_score),
                                                  new_appeared_pttrns_nmbs[i],
                                                  (*gluing_matrix)[ (*A_n_k_elmnt).elmnt[  j  ] ]
                                                                  [ (*A_n_k_elmnt).elmnt[j + 1] ].appeared_pttrns_nmbs[k],
                                                  &((*A_n_k_elmnt).max_pttrn_cmplx_nmbs)                                  )  )
                {
                    return 0;
                }
            }
        }
    }
    return 1;
}

short int nmb_in_interval_test (unsigned long int nmb,
                                unsigned long int left_interval_border,
                                unsigned long int right_interval_border)
{
    if (left_interval_border > right_interval_border)
    {
        cout << "interval test error: left border > right border" << endl;
        return 2;
    }

    if (nmb < left_interval_border)
        return -1;

    if (nmb > right_interval_border)
        return 1;

    return 0;
}

bool forbidden_A_n_k_elmnt_nmb_test( unsigned short int pttrn_base_size,
                                     unsigned short int current_iter_nmb,
                                     unsigned long int* current_A_n_k_elmnt_nmb,
                                     vector< vector<unsigned long int> >* forbidden_A_n_k_elmnts_nmbs_stat )
{
    for ( unsigned short int i = 0;
          i < (*forbidden_A_n_k_elmnts_nmbs_stat).size();
          i++ )
    {
        if ( (i + 1) == current_iter_nmb )
            break;

        for (unsigned long int j = 0;
             j < (*forbidden_A_n_k_elmnts_nmbs_stat)[i].size();
             j++)
        {
            switch( nmb_in_interval_test ( (*current_A_n_k_elmnt_nmb),

                                           (*forbidden_A_n_k_elmnts_nmbs_stat)[i][j]
                                           *
                                           int_pow( pttrn_base_size,
                                                    current_iter_nmb - (i + 1) ),

                                           ( (*forbidden_A_n_k_elmnts_nmbs_stat)[i][j] + 1 )
                                           *
                                           int_pow( pttrn_base_size,
                                                    current_iter_nmb - (i + 1) )            ) )
            {
                case 0:
                    (*current_A_n_k_elmnt_nmb) = 1 + ((*forbidden_A_n_k_elmnts_nmbs_stat)[i][j] + 1)
                                                     *
                                                     int_pow( pttrn_base_size,
                                                              current_iter_nmb - (i + 1) );
                    return 0;

                case -1:
                    j = (*forbidden_A_n_k_elmnts_nmbs_stat)[i].size() + 1;
                    break;
            }
        }
    }
    return 1;
}

void olig_from_nmbs_to_string_convert (string* str_olig,
                                       vector<unsigned short int>* nmbs_olig,
                                       vector<string>* pttrn_base);

void A_n_k_maker_stat_writer ( ofstream* write,
                               vector<unsigned short int>* nmbs_olig,
                               float max_pttrn_cmplx_dG_score,
                               vector<string>* pttrn_base)
{
    string olig;

    olig_from_nmbs_to_string_convert( &olig,
                                      nmbs_olig,
                                      pttrn_base  );

    (*write) << olig << '\t' << max_pttrn_cmplx_dG_score << endl;
}

/*
void A_n_k_maker_stat_writer ( ofstream* write,
                               int iter_nmb,
                               vector< A_n_k_elmnt >* A_n_k,
                               vector< vector<unsigned short int> >*
                                     forbidden_A_n_k_elmnts_nmbs_stat)
{
    (*write) << endl << iter_nmb << endl << endl;

    char sep = '\t';

    for (int i = 0; i < (*A_n_k).size(); i++)
    {
        (*write) << sep << (*A_n_k)[i].nmb << sep;

        write_vect_as_string <unsigned short int> ( &((*A_n_k)[i].elmnt),
                                                     write                );
        (*write) << endl;
    }
    (*write) << endl;

    for (int j = 0; j < (*forbidden_A_n_k_elmnts_nmbs_stat)[iter_nmb].size(); j++)
    {
        (*write) << sep << (*forbidden_A_n_k_elmnts_nmbs_stat)[iter_nmb][j] << endl;
    }
}
*/
void ten_to_n_nmb_sys (unsigned long int ten_nmb,
                       unsigned short int n,
                       vector<unsigned short int>* n_nmb,
                       unsigned short int n_nmb_final_size )
{
    unsigned short int excess;

    (*n_nmb).clear();

    while (ten_nmb > n)
    {
        excess = ten_nmb % n;
        (*n_nmb).insert( (*n_nmb).begin(), excess );
        ten_nmb /= n;
    }
    (*n_nmb).insert( (*n_nmb).begin(), ten_nmb );

    while( (*n_nmb).size() < n_nmb_final_size )
    {
        (*n_nmb).insert( (*n_nmb).begin(), 0 );
    }
}

bool modified_A_n_k_maker ( vector<string>* pttrn_base,
                            unsigned short int n,
                            unsigned short int k,
                            float crit_score,
                            vector< vector<two_pttrn_gluing> >* gluing_matrix )
{
    if ( n < k )
        return 1;

    vector< vector<unsigned long int> > forbidden_A_n_k_elmnts_nmbs_stat;

    ofstream write ("../output/A_n_k_maker_stat");
    //ofstream dbg_write_0_1 ("../output/A_n_k_maker_stat_dbg_0_1");
    //ofstream dbg_write_0_0 ("../output/A_n_k_maker_stat_dbg_0_0");
    //ofstream dbg_write_1_0 ("../output/A_n_k_maker_stat_dbg_1_0");
/*
    A_n_k_maker_stat_writer(&write,
                            0,
                            A_n_k,
                            &forbidden_A_n_k_elmnts_nmbs_stat);
*/

    A_n_k_elmnt_struct current_A_n_k_elmnt;
    vector<unsigned long int> init_vect;

    for (int iter_nmb = 1; iter_nmb <= k; iter_nmb++)
    {
        forbidden_A_n_k_elmnts_nmbs_stat.push_back(init_vect);

        for (unsigned long int current_A_n_k_elmnt_nmb = 0;
             current_A_n_k_elmnt_nmb < int_pow( (*gluing_matrix).size(), iter_nmb );
             current_A_n_k_elmnt_nmb++)
        {
//if (iter_nmb == 3) cout << endl << "Q" << endl;

            ten_to_n_nmb_sys (current_A_n_k_elmnt_nmb,
                              (*gluing_matrix).size(),
                              &(current_A_n_k_elmnt.elmnt),
                              iter_nmb                     );
//if (iter_nmb == 3) cout << endl << "W" << endl;
            if ( !forbidden_A_n_k_elmnt_nmb_test( (*gluing_matrix).size(),
                                                  iter_nmb,
                                                  &current_A_n_k_elmnt_nmb,
                                                  &forbidden_A_n_k_elmnts_nmbs_stat ) )
            {
                //cout << current_A_n_k_elmnt_nmb << endl;
                continue;
            }

//if (iter_nmb == 3) cout << endl << "E" << endl;
//if (iter_nmb == 3) cout << endl << current_A_n_k_elmnt.elmnt[0] << '\t'
                                //<< current_A_n_k_elmnt.elmnt[1] << '\t'
                                //<< current_A_n_k_elmnt.elmnt[2] << '\t'  << endl;

            if ( A_n_k_elmnt_test( &current_A_n_k_elmnt,
                                   crit_score,
                                   gluing_matrix        ) )
            {
//if (iter_nmb == 3) cout << endl << "R" << endl;
                    write << current_A_n_k_elmnt_nmb << '\t';
                    A_n_k_maker_stat_writer ( &write,
                                              &(current_A_n_k_elmnt.elmnt),
                                              current_A_n_k_elmnt.max_pttrn_cmplx_dG_score,
                                              pttrn_base );
//if (iter_nmb == 3) cout << endl << "T" << endl;
                    current_A_n_k_elmnt.max_pttrn_cmplx_nmbs.clear();
            }
            else
            {
//if (iter_nmb == 3) cout << endl << "Y" << endl;
                forbidden_A_n_k_elmnts_nmbs_stat
                [forbidden_A_n_k_elmnts_nmbs_stat.size() - 1].
                push_back( current_A_n_k_elmnt_nmb );
/*
                dbg_write_1_0 << iter_nmb << '\t' << i << '\t' << j << endl
                              << current_A_n_k_elmnt.max_pttrn_cmplx_nmbs[0] << '\t'
                                       << current_A_n_k_elmnt.max_pttrn_cmplx_nmbs[1] << endl;

                         A_n_k_maker_stat_writer ( &dbg_write_1_0,
                                                   &(current_A_n_k_elmnt.elmnt),
                                                   current_A_n_k_elmnt.max_pttrn_cmplx_dG_score,
                                                   pttrn_base);
*/
                current_A_n_k_elmnt.max_pttrn_cmplx_nmbs.clear();
            }
            cout << current_A_n_k_elmnt.max_pttrn_cmplx_dG_score << endl;
        }
        write << endl << endl;
    }
    write.close();
    return 0;
}
