#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#include "my_structs.h"

using namespace std;

void input_data_reader (bool*    gluing_matrix_count_flag,
                        bool*    dna_flag,
                        int*     pttrn_length,
                        int*     pttrn_nmb_in_olig,
                        float*   crit_score,
                        char     sep = ' '        );

void pttrn_base_generator (vector<string>* pttrn_base,
                           int pttrn_length,
                           bool dna_flag);

bool gluing_matrix_maker (vector<string>* pttrn_base,
                          vector< vector<two_pttrn_gluing> >* gluing_matrix,
                          bool dna_flag);

bool gluing_matrix_reader( vector< vector<two_pttrn_gluing> >* gluing_matrix,
                           int gluing_matrix_size );

bool modified_A_n_k_maker ( vector<string>* pttrn_base,
                            unsigned short int n,
                            unsigned short int k,
                            float crit_score,
                            vector< vector<two_pttrn_gluing> >* gluing_matrix );

void result_data_writer (float crit_score,
                         int pttrn_length,
                         bool dna_flag,
                         vector<string>* pttrn_base,
                         vector< A_n_k_elmnt_with_nmb >* final_oligs_base);

void result_data_worker(bool dna_flag);

#endif // MAIN_H_INCLUDED
